import chalk from "chalk";
import fs from "fs";
import readline from "readline";
import { bebopExchange } from "./main/bebopExchange";
import { gteDex } from "./main/gte";
import { getRandomProxy, loadProxies } from "./main/proxy";
import { rainmakrDex } from "./main/rainmark";
import { tekoMint } from "./main/tekoMint";
import { logMessage } from "./utils/logger";


const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function displayBanner(): void {
  console.log(
    chalk.cyan(`
░█▄█░█▀▀░█▀▀░█▀█░█▀▀░▀█▀░█░█
░█░█░█▀▀░█░█░█▀█░█▀▀░░█░░█▀█
░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░░▀░░▀░▀
  By : El Puqus Airdrop
   github.com/ahlulmukh
 Use it at your own risk
  `)
  );
}

function displayMenu(): void {
  console.log(chalk.yellow("\n---- Bepop Exchange ----"));
  console.log("1. ETH -> WETH");
  console.log("2. WETH -> ETH");
  console.log("3. Random swap ETH <-> WETH");
  console.log(chalk.yellow("\n---- Teko Mint ----"));
  console.log("4. Mint tkETH (1)");
  console.log("5. Mint tkUSDC (2000)");
  console.log("6. Mint tkBTC (0.02)");
  console.log("7. Mint cUSDC (1000)");
  console.log("8. Mint All");
  console.log(chalk.yellow("\n---- GTE ----"));
  console.log("9. Auto Swap Random Tokens");
  console.log("10. Swap All To ETH");
  console.log(chalk.yellow("\n---- RAINMAKR ----"));
  console.log("11. Auto Swap Random in List Token");
  console.log("12. Buy custom token");
  console.log("13. Sell all custom token");
  console.log("14. Swap All Token to ETH")
  console.log("15. Buy and sell random trending token")
  console.log("16. Buy and sell random top MCAP token")
  console.log(chalk.yellow("\n0. Exit"));
}

async function getUserChoice(): Promise<number> {
  // Otomatis return 17 tanpa meminta input dari user
  return 17;
}

async function getUserInput(prompt: any): Promise<any> {
  return new Promise((resolve) => {
    rl.question(prompt, (input: any) => {
      resolve(input.trim());
    });
  });
}

async function processAccount(
  privkey: string,
  currentNum: number,
  total: number,
  choice: number
): Promise<boolean> {
  const currentProxy = await getRandomProxy(currentNum, total);
  const bepop = new bebopExchange(privkey, currentProxy, currentNum, total);
  const minter = new tekoMint(privkey, currentProxy, currentNum, total);
  const gteSwap = new gteDex(privkey, currentProxy, currentNum, total);
  const rainmakr = new rainmakrDex(privkey, currentProxy, currentNum, total);

  try {
    console.log(chalk.white("-".repeat(85)));
    logMessage(currentNum, total, `Processing Account ${currentNum}/${total}`, "info");

    switch (choice) {
      case 1: 
        await bepop.depositETH(1, 0.01);
        break;
      case 2: {
        await bepop.withdrawETH(1, 0.01);
        break;
      }
      case 3:
        await bepop.autoSwapETHWETH(1, 0.01);
        break;
      case 4:
        await minter.mint(minter.tkETH, 1);
        break;
      case 5:
        await minter.mint(minter.tkUSDC, 2000);
        break;
      case 6:
        await minter.mint(minter.tkBTC, 0.02);
        break;
      case 7:
        await minter.mint(minter.cUSDC, 1000);
        break;
      case 8:
        await minter.mint(minter.tkETH, 1);
        await minter.mint(minter.tkUSDC, 2000);
        await minter.mint(minter.tkBTC, 0.02);
        await minter.mint(minter.cUSDC, 1000);
        break;
      case 9:
        await gteSwap.autoSwap();
        break;
      case 10:
        await gteSwap.swapAllTokensToETH();
        break;
      case 11:
        await rainmakr.autoSwap();
        break;
      case 12:
        try {
          const buyTokenAddress = await getUserInput("Enter token address to buy: ");
          const buyAmount = parseFloat(await getUserInput("Enter ETH amount to spend: "));
          if (isNaN(buyAmount)) throw new Error("Invalid amount");
          await rainmakr.customBuy(buyTokenAddress, buyAmount);
        } catch (error) {
          console.log(chalk.red(`Error: ${(error as Error).message}`));
        }
        break;
      case 13:
        try {
          const sellTokenAddress = await getUserInput("Enter token address to sell: ");
          await rainmakr.sellAllToken(sellTokenAddress);
        } catch (error) {
          console.log(chalk.red(`Error: ${(error as Error).message}`));
        }
        break
      case 14:
        await rainmakr.swapAllTokensToETH();
        break;
      case 15:
        await rainmakr.buyAndSellRandomToken();
        break;
      case 16:
        await rainmakr.buyAndSellRandomTokenTopMcap();
        break;
      case 17:
        await bepop.depositETH(1, 0.01);
        await bepop.withdrawETH(1, 0.01);
        await bepop.autoSwapETHWETH(1, 0.01);
        await minter.mint(minter.tkETH, 1);
        await minter.mint(minter.tkUSDC, 2000);
        await minter.mint(minter.tkBTC, 0.02);
        await minter.mint(minter.cUSDC, 1000);
        await minter.mint(minter.tkETH, 1);
        await minter.mint(minter.tkUSDC, 2000);
        await minter.mint(minter.tkBTC, 0.02);
        await minter.mint(minter.cUSDC, 1000);
        await gteSwap.autoSwap();
        await gteSwap.swapAllTokensToETH();
        await rainmakr.autoSwap();
        await rainmakr.swapAllTokensToETH();
        await rainmakr.buyAndSellRandomToken();
        await rainmakr.buyAndSellRandomTokenTopMcap();
        break;
      }

    return true;
  } catch (err) {
    logMessage(currentNum, total, `Error: ${(err as any).message}`, "error");
    return false;
  }
}

async function main(): Promise<void> {
  displayBanner();

  const accounts = fs
    .readFileSync("privatekey.txt", "utf8")
    .split("\n")
    .filter(Boolean);
  const count = accounts.length;

  const proxiesLoaded = loadProxies();
  if (!proxiesLoaded) {
    logMessage(null, null, "No Proxy. Using default IP", "info");
  }

  let running = true;
  while (running) {
    displayMenu();
    const choice = await getUserChoice();

    if (choice === 0) {
      running = false;
      console.log(chalk.blue("Exiting..."));
      break;
    }

    let successful = 0;
    for (let i = 0; i < count; i++) {
      const success = await processAccount(accounts[i], i + 1, count, choice);
      if (success) successful++;
    }

    console.log(chalk.green(`\nCompleted! Successful transactions: ${successful}/${count}`));
  }

  rl.close();
}

main().catch((err) => {
  console.error(chalk.red("Error occurred:"), err);
  process.exit(1);
});