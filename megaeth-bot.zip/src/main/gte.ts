import { ethers, FetchRequest } from "ethers";
import fs from "fs";
import path from "path";
import { ERC20_ABI, GTE_TOKENS, ROUTER_ABI } from "../config/gteabi";
import { logMessage } from "../utils/logger";
import { getProxyAgent } from "./proxy";
const configPath = path.resolve(__dirname, "../../config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));


export class gteDex {
    private privkey: string;
    private web3: any;
    private explorer: string;
    private RPC: string;
    private swapaddress: string = "0xa6b579684e943f7d00d616a48cf99b5147fc57a5";
    private swapContract: any;
    private wallet: any;
    private proxy: string | null;
    private currentNum: number;
    private total: number;


    constructor(privkey: string, proxy: string | null = null, currentNum: number, total: number) {
        this.RPC = config.RPC_URL;
        this.explorer = config.EXPLORE_URL;
        this.privkey = privkey;
        this.web3 = this.initializeWeb3();
        this.wallet = new ethers.Wallet(this.privkey, this.web3);

        this.swapContract = new ethers.Contract(this.swapaddress, ROUTER_ABI, this.wallet);
        this.currentNum = currentNum;
        this.total = total
        this.proxy = proxy;
    }

    private initializeWeb3() {
        if (this.proxy) {
            FetchRequest.registerGetUrl(
                FetchRequest.createGetUrlFunc({
                    agent: getProxyAgent(this.proxy, this.currentNum, this.total),
                })
            );
            return new ethers.JsonRpcProvider(this.RPC);
        }
        return new ethers.JsonRpcProvider(this.RPC);
    }

    private async approve(tokenAddress: string, amount: bigint): Promise<void> {
        const tokenContract = new ethers.Contract(tokenAddress, ERC20_ABI, this.wallet);
        const feeData = await this.web3.getFeeData();
        const tx = await tokenContract.approve(
            this.swapaddress,
            amount,
            {
                gasLimit: 100000,
                maxFeePerGas: feeData.maxFeePerGas || undefined,
                maxPriorityFeePerGas: feeData.maxPriorityFeePerGas || undefined
            }
        );
        await tx.wait();
    }

    private ensureChecksum(address: string): string {
        try {
            return ethers.getAddress(address);
        } catch (error) {
            throw new Error(`Invalid address format: ${address}`);
        }
    }

    async swap(tokenIn: string, tokenOut: string, amountDecimal: number): Promise<any> {
        const tokenInData = GTE_TOKENS[tokenIn as keyof typeof GTE_TOKENS];
        const tokenOutData = GTE_TOKENS[tokenOut as keyof typeof GTE_TOKENS];
        const deadline = Math.floor(Date.now() / 1000) + 1800;
        const amountIn = BigInt(amountDecimal * (10 ** tokenInData.decimals));
        const amountOutMin = 0;
        const BASE_TOKEN = "ETH";
        if (tokenIn !== BASE_TOKEN && tokenInData.address === null) {
            throw new Error(`Token ${tokenIn} has no contract address`);
        }
        if (tokenOut !== BASE_TOKEN && tokenOutData.address === null) {
            throw new Error(`Token ${tokenOut} has no contract address`);
        }

        const maxRetries = 3;
        let retryCount = 0;

        while (retryCount < maxRetries) {
            try {
                let tx;
                let nonce = await this.web3.getTransactionCount(this.wallet.address, 'pending');
                if (retryCount > 0) {
                    nonce += 1;
                }

                if (tokenIn === BASE_TOKEN) {
                    const path = [
                        this.ensureChecksum(GTE_TOKENS["WETH"].address!),
                        this.ensureChecksum(tokenOutData.address!)
                    ];
                    tx = await this.swapContract.swapExactETHForTokens(
                        amountOutMin,
                        path,
                        this.wallet.address,
                        deadline,
                        { value: amountIn, gasLimit: 300000, nonce }
                    );
                }
                else if (tokenOut === BASE_TOKEN) {
                    await this.approve(this.ensureChecksum(tokenInData.address!), amountIn);
                    const path = [this.ensureChecksum(tokenInData.address!), this.ensureChecksum(GTE_TOKENS["WETH"].address!)];
                    tx = await this.swapContract.swapExactTokensForETH(
                        amountIn,
                        amountOutMin,
                        path,
                        this.wallet.address,
                        deadline,
                        { gasLimit: 300000, nonce }
                    );
                }
                else {
                    await this.approve(this.ensureChecksum(tokenInData.address!), amountIn);
                    const path = [
                        this.ensureChecksum(tokenInData.address!),
                        this.ensureChecksum(GTE_TOKENS["WETH"].address!),
                        this.ensureChecksum(tokenOutData.address!)
                    ];
                    tx = await this.swapContract.swapExactTokensForTokens(
                        amountIn,
                        amountOutMin,
                        path,
                        this.wallet.address,
                        deadline,
                        { gasLimit: 300000, nonce }
                    );
                }

                const receipt = await tx.wait();
                return receipt;

            } catch (error: any) {
                if (error.message.includes("nonce too low") || error.message.includes("already known")) {
                    retryCount += 1;
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    continue;
                }
                throw error;
            }
        }
        throw new Error("Failed to swap after several attempts");
    }

    async autoSwap() {
        const tokens = Object.keys(GTE_TOKENS).filter(t => t !== "ETH");
        const count = 3;

        for (let i = 0; i < count; i++) {
            const tokenIn = "ETH";
            const tokenOut = tokens[Math.floor(Math.random() * tokens.length)];
            const amount = 0.01;

            try {
                logMessage(this.currentNum, this.total, `Attempting swap ${tokenIn} → ${tokenOut}`, "info");
                const receipt = await this.swap(tokenIn, tokenOut, amount);
                logMessage(this.currentNum, this.total, `Swap successful! Tx hash: ${receipt.hash}`, "success");
                logMessage(this.currentNum, this.total, `Block explorer: ${this.explorer}${receipt.hash}`, "success");
            } catch (error: any) {
                logMessage(this.currentNum, this.total, `Swap failed: ${error.message}`, "error");
            }
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }

    async swapAllTokensToETH(): Promise<void> {
        const BASE_TOKEN = "ETH";
        const tokens = Object.keys(GTE_TOKENS).filter(t => t !== BASE_TOKEN);
        logMessage(this.currentNum, this.total, "Starting to swap all tokens to ETH", "info");
        for (const token of tokens) {
            try {
                const tokenData = GTE_TOKENS[token as keyof typeof GTE_TOKENS];
                if (!tokenData.address) {
                    logMessage(this.currentNum, this.total, `Skipping ${token} (no contract address)`, "info");
                    continue;
                }

                const tokenContract = new ethers.Contract(
                    this.ensureChecksum(tokenData.address),
                    ERC20_ABI,
                    this.wallet
                );
                const balance = await tokenContract.balanceOf(this.wallet.address);
                if (balance === BigInt(0)) {
                    logMessage(this.currentNum, this.total, `No ${token} balance to swap`, "info");
                    continue;
                }
                const balanceFormatted = ethers.formatUnits(balance, tokenData.decimals);
                logMessage(this.currentNum, this.total, `Swapping ${balanceFormatted} ${token} to ETH...`, "process")
                const amountToSwap = balance * BigInt(995) / BigInt(1000);
                const amountToSwapFormatted = Number(ethers.formatUnits(amountToSwap, tokenData.decimals));

                const approveTx = await tokenContract.approve(
                    this.swapaddress,
                    amountToSwap,
                    {
                        gasLimit: 100000,
                        maxFeePerGas: (await this.web3.getFeeData()).maxFeePerGas || undefined
                    }
                );
                await approveTx.wait();
                logMessage(this.currentNum, this.total, `Approval succesfulyy : ${this.explorer}${approveTx.hash}`, "success");

                const path = [
                    this.ensureChecksum(tokenData.address),
                    this.ensureChecksum(GTE_TOKENS["WETH"].address!)
                ];

                const swapTx = await this.swapContract.swapExactTokensForETH(
                    amountToSwap,
                    0,
                    path,
                    this.wallet.address,
                    Math.floor(Date.now() / 1000) + 1800,
                    {
                        gasLimit: 300000,
                        maxFeePerGas: (await this.web3.getFeeData()).maxFeePerGas || undefined
                    }
                );

                const swapReceipt = await swapTx.wait();
                logMessage(this.currentNum, this.total, `Swap successfully : ${this.explorer}${swapTx.hash}`, "success");
                logMessage(this.currentNum, this.total, `${amountToSwapFormatted} ${token} → ETH`, "success");
                await new Promise(resolve => setTimeout(resolve, 2000));

            } catch (error: any) {
                logMessage(this.currentNum, this.total, `Failed to swap ${token}: ${error.message}`, "error");
                continue;
            }
        }

        logMessage(this.currentNum, this.total, "All tokens swapped to ETH successfully!", "success");
    }
}