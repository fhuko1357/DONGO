import chalk from "chalk";
import { ethers, FetchRequest } from "ethers";
import fs from "fs";
import path from "path";
import { SWAP_BEPOP } from "../config/bebop";
import { logMessage } from "../utils/logger";
import { getProxyAgent } from "./proxy";
const configPath = path.resolve(__dirname, "../../config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));


export class bebopExchange {
    private privkey: string;
    private web3: any;
    private explorer: string;
    private RPC: string;
    private bepopAddress: string = "0x4eb2bd7bee16f38b1f4a0a5796fffd028b6040e9";
    private wallet: any;
    private bepopContract: any;
    private proxy: string | null;
    private currentNum: number;
    private total: number;


    constructor(privkey: string, proxy: string | null = null, currentNum: number, total: number) {
        this.RPC = config.RPC_URL;
        this.explorer = config.EXPLORE_URL;
        this.privkey = privkey;
        this.web3 = this.initializeWeb3();
        this.wallet = new ethers.Wallet(this.privkey, this.web3);
        this.bepopContract = new ethers.Contract(this.bepopAddress, SWAP_BEPOP, this.wallet);
        this.currentNum = currentNum;
        this.total = total
        this.proxy = proxy;
    }

    private initializeWeb3() {
        if (this.proxy) {
            FetchRequest.registerGetUrl(
                FetchRequest.createGetUrlFunc({
                    agent: getProxyAgent(this.proxy, this.currentNum, this.total),
                })
            );
            return new ethers.JsonRpcProvider(this.RPC);
        }
        return new ethers.JsonRpcProvider(this.RPC);
    }

    async depositETH(countInput: number, maxAmountETH: number) {
        const count = countInput;
        for (let i = 0; i < count; i++) {
            try {
                logMessage(this.currentNum, this.total, `Depositing ${i + 1}/${count}`, "process");
                logMessage(this.currentNum, this.total, `Depositing ${maxAmountETH} ETH into WETH...`, "process");
                const randomPercent = Math.random() * 0.9 + 0.1;
                const randomAmount = (maxAmountETH * randomPercent).toFixed(6);
                const tx = await this.bepopContract.deposit({
                    value: ethers.parseEther(randomAmount)
                });
                await tx.wait();
                logMessage(this.currentNum, this.total, `Deposit success, tx hash: ${tx.hash}`, "success");
                logMessage(this.currentNum, this.total, `Explorer URL: ${this.explorer}${tx.hash}`, "success");
                console.log(chalk.white("-".repeat(85)));
                await this.sleep(5000);
            } catch (error: any) {
                logMessage(this.currentNum, this.total, `Deposit failed: ${error.message}`, "error");
            }
        }

    }

    async withdrawETH(countInput: number, maxAmountETH: number) {
        const count = countInput;
        for (let i = 0; i < count; i++) {
            try {
                logMessage(this.currentNum, this.total, `Withdrawing ${i + 1}/${count}`, "process");
                logMessage(this.currentNum, this.total, `Withdrawing ${maxAmountETH} WETH into ETH...`, "process");
                const randomPercent = Math.random() * 0.9 + 0.1;
                const randomAmount = (maxAmountETH * randomPercent).toFixed(6);
                const amount = ethers.parseEther(randomAmount);
                const tx = await this.bepopContract.withdraw(amount);
                await tx.wait();
                logMessage(this.currentNum, this.total, `Withdraw success, tx hash: ${tx.hash}`, "success");
                logMessage(this.currentNum, this.total, `Explorer URL: ${this.explorer}${tx.hash}`, "success");
                console.log(chalk.white("-".repeat(85)));
                await this.sleep(5000);
            } catch (error: any) {
                logMessage(this.currentNum, this.total, `Withdraw failed: ${error.message}`, "error");
            }
        }

    }

    async autoSwapETHWETH(countInput: number, maxAmountETH: number) {
        const count = countInput;
        for (let i = 0; i < count; i++) {
            logMessage(this.currentNum, this.total, `Auto swap ${i + 1}/${count}`, "process");
            const randomPercent = Math.random() * 0.9 + 0.1;
            const randomAmount = (maxAmountETH * randomPercent).toFixed(6);

            const isDeposit = Math.random() < 0.5;
            const ethBalance = await this.web3.getBalance(this.wallet.address);
            const wethBalance = await this.bepopContract.balanceOf(this.wallet.address);

            logMessage(this.currentNum, this.total, `Balance Before Swap:`, "info");
            logMessage(this.currentNum, this.total, `ETH Balance: ${ethers.formatEther(ethBalance)}`, "info");
            logMessage(this.currentNum, this.total, `WETH Balance: ${ethers.formatEther(wethBalance)}`, "info");
            console.log(chalk.white("-".repeat(85)));

            try {
                if (isDeposit) {
                    if (ethBalance > ethers.parseEther(randomAmount)) {
                        logMessage(this.currentNum, this.total,
                            `Swap: ETH -> WETH [${randomAmount} ETH]`,
                            "process");
                        const tx = await this.bepopContract.deposit({
                            value: ethers.parseEther(randomAmount)
                        });
                        await tx.wait();
                        logMessage(this.currentNum, this.total, `Swap ETH -> WETH Successful`, "success");
                        logMessage(this.currentNum, this.total, `Explorer URL: ${this.explorer}${tx.hash}`, "success");
                    } else {
                        logMessage(this.currentNum, this.total,
                            `Not enough ETH to deposit (needed: ${randomAmount})`,
                            "error");
                    }
                } else {
                    if (wethBalance > ethers.parseEther(randomAmount)) {
                        logMessage(this.currentNum, this.total,
                            `Swap: WETH -> ETH [${randomAmount} WETH]`,
                            "process");
                        const tx = await this.bepopContract.withdraw(
                            ethers.parseEther(randomAmount)
                        );
                        await tx.wait();
                        logMessage(this.currentNum, this.total, `Swap WETH -> ETH Successful`, "success");
                        logMessage(this.currentNum, this.total, `Explorer URL: ${this.explorer}${tx.hash}`, "success");
                    } else {
                        logMessage(this.currentNum, this.total,
                            `Not enough WETH to withdraw (needed: ${randomAmount})`,
                            "error");
                    }
                }
            } catch (error: any) {
                logMessage(this.currentNum, this.total,
                    `Swap failed: ${error.message}`,
                    "error");
            }

            console.log(chalk.white("-".repeat(85)));
            await this.sleep(5000);
        }
    }

    private sleep(ms: number) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }


}