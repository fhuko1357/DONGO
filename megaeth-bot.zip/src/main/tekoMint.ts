import { ethers, FetchRequest } from "ethers";
import fs from "fs";
import path from "path";
import { MINT_ABI } from "../config/teko";
import { logMessage } from "../utils/logger";
import { getProxyAgent } from "./proxy";

const configPath = path.resolve(__dirname, "../../config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));


export class tekoMint {
    private privkey: string;
    private web3: any;
    private explorer: string;
    private RPC: string;
    public tkETH: string = "0x176735870dc6c22b4ebfbf519de2ce758de78d94"
    public tkUSDC: string = "0xfaf334e157175ff676911adcf0964d7f54f2c424"
    public tkBTC: string = "0xf82ff0799448630eb56ce747db840a2e02cde4d8"
    public cUSDC: string = "0xe9b6e75c243b6100ffcb1c66e8f78f96feea727f"
    private wallet: any;
    private proxy: string | null;
    private currentNum: number;
    private total: number;
    private decimals: { [address: string]: number } = {
        "0x176735870dc6c22b4ebfbf519de2ce758de78d94": 18,
        "0xfaf334e157175ff676911adcf0964d7f54f2c424": 6,
        "0xf82ff0799448630eb56ce747db840a2e02cde4d8": 8,
        "0xe9b6e75c243b6100ffcb1c66e8f78f96feea727f": 6
    };

    constructor(privkey: string, proxy: string | null = null, currentNum: number, total: number) {
        this.RPC = config.RPC_URL;
        this.explorer = config.EXPLORE_URL;
        this.privkey = privkey;
        this.web3 = this.initializeWeb3();
        this.wallet = new ethers.Wallet(this.privkey, this.web3);
        this.currentNum = currentNum;
        this.total = total
        this.proxy = proxy;
    }

    private initializeWeb3() {
        if (this.proxy) {
            FetchRequest.registerGetUrl(
                FetchRequest.createGetUrlFunc({
                    agent: getProxyAgent(this.proxy, this.currentNum, this.total),
                })
            );
            return new ethers.JsonRpcProvider(this.RPC);
        }
        return new ethers.JsonRpcProvider(this.RPC);
    }

    async mint(tokenAddress: string, amount: number) {
        try {
            const contract = new ethers.Contract(tokenAddress, MINT_ABI, this.wallet);
            const decimal = this.decimals[tokenAddress];
            if (decimal === undefined) {
                throw new Error(`Decimal not set for token address: ${tokenAddress}`);
            }
            const formattedAmount = ethers.parseUnits(amount.toString(), decimal);
            const tx = await contract.mint(this.wallet.address, formattedAmount);
            logMessage(this.currentNum, this.total, `Minting ${amount} tokens...`, "info");
            await tx.wait();
            logMessage(this.currentNum, this.total, `Minted ${amount} tokens successfully`, "success");
            logMessage(this.currentNum, this.total, `Explorer URL: ${this.explorer}${tx.hash}`, "success");
        } catch (err) {
            console.error(`Mint failed: ${err}`);
        }
    }


}