import axios from "axios";
import { ethers, FetchRequest } from "ethers";
import fs from "fs";
import path from "path";
import UserAgent from "user-agents";
import { ERC20_ABI, RAINMAKR_TOKENS, ROUTER_ABI } from "../config/rainmarkabi";
import { logMessage } from "../utils/logger";
import { getProxyAgent } from "./proxy";
const userAgent = new UserAgent();
const configPath = path.resolve(__dirname, "../../config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));


export class rainmakrDex {
    private privkey: string;
    private web3: any;
    private explorer: string;
    private RPC: string;
    private swapaddress: string = "0x6cefc3bf9813693aaccd59cffca3b0b2e54b0545";
    private wethAddress: string = "0x4eB2Bd7beE16F38B1F4a0A5796Fffd028b6040e9";
    private swapContract: any;
    private wallet: any;
    private proxy: string | null;
    private currentNum: number;
    private total: number;
    private axiosConfig: any;


    constructor(privkey: string, proxy: string | null = null, currentNum: number, total: number) {
        this.RPC = config.RPC_URL;
        this.explorer = config.EXPLORE_URL;
        this.privkey = privkey;
        this.web3 = this.initializeWeb3();
        this.wallet = new ethers.Wallet(this.privkey, this.web3);
        this.swapContract = new ethers.Contract(this.swapaddress, ROUTER_ABI, this.wallet);
        this.currentNum = currentNum;
        this.total = total
        this.proxy = proxy;
        this.axiosConfig = {
            ...(this.proxy && { httpsAgent: getProxyAgent(this.proxy, this.currentNum, this.total) }),
            timeout: 60000,
            headers: {
                "User-Agent": userAgent.toString(),
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        };
    }

    async makeRequest(method: string, url: string, config: any = {}) {
        try {
            const response = await axios({
                method,
                url,
                ...this.axiosConfig,
                ...config,
                validateStatus: (status) => status < 500,
            });
            return response;
        } catch (error) {
            logMessage(this.currentNum, this.total, `Request failed: ${(error as any).message}`, "error");
        }
    }


    private initializeWeb3() {
        if (this.proxy) {
            FetchRequest.registerGetUrl(
                FetchRequest.createGetUrlFunc({
                    agent: getProxyAgent(this.proxy, this.currentNum, this.total),
                })
            );
            return new ethers.JsonRpcProvider(this.RPC);
        }
        return new ethers.JsonRpcProvider(this.RPC);
    }

    private async approve(tokenAddress: string, amount: bigint): Promise<void> {
        const tokenContract = new ethers.Contract(tokenAddress, ERC20_ABI, this.wallet);
        const feeData = await this.web3.getFeeData();
        const tx = await tokenContract.approve(
            this.swapaddress,
            amount,
            {
                gasLimit: 100000,
                maxFeePerGas: feeData.maxFeePerGas || undefined,
                maxPriorityFeePerGas: feeData.maxPriorityFeePerGas || undefined
            }
        );
        await tx.wait();
    }

    private ensureChecksum(address: string): string {
        try {
            return ethers.getAddress(address);
        } catch (error) {
            throw new Error(`Invalid address format: ${address}`);
        }
    }

    private async swap(tokenIn: string, tokenOut: string, amountDecimal: number): Promise<any> {
        const tokenInData = RAINMAKR_TOKENS[tokenIn as keyof typeof RAINMAKR_TOKENS];
        const tokenOutData = RAINMAKR_TOKENS[tokenOut as keyof typeof RAINMAKR_TOKENS];
        const deadline = Math.floor(Date.now() / 1000) + 1800;
        const amountIn = BigInt(amountDecimal * (10 ** tokenInData.decimals));
        const amountOutMin = 0;
        const BASE_TOKEN = "ETH";
        if (tokenIn !== BASE_TOKEN && tokenInData.address === null) {
            throw new Error(`Token ${tokenIn} has no contract address`);
        }
        if (tokenOut !== BASE_TOKEN && tokenOutData.address === null) {
            throw new Error(`Token ${tokenOut} has no contract address`);
        }

        const maxRetries = 3;
        let retryCount = 0;

        while (retryCount < maxRetries) {
            try {
                let tx;
                let nonce = await this.web3.getTransactionCount(this.wallet.address, 'pending');
                if (retryCount > 0) {
                    nonce += 1;
                }

                if (tokenIn === BASE_TOKEN) {
                    const path = [
                        this.ensureChecksum(this.wethAddress!),
                        this.ensureChecksum(tokenOutData.address!)
                    ];
                    tx = await this.swapContract.swapExactETHForTokens(
                        amountOutMin,
                        path,
                        this.wallet.address,
                        deadline,
                        { value: amountIn, gasLimit: 300000, nonce }
                    );
                }
                else if (tokenOut === BASE_TOKEN) {
                    await this.approve(this.ensureChecksum(tokenInData.address!), amountIn);
                    const path = [this.ensureChecksum(tokenInData.address!), this.ensureChecksum(this.wethAddress!)];
                    tx = await this.swapContract.swapExactTokensForETH(
                        amountIn,
                        amountOutMin,
                        path,
                        this.wallet.address,
                        deadline,
                        { gasLimit: 300000, nonce }
                    );
                }
                else {
                    await this.approve(this.ensureChecksum(tokenInData.address!), amountIn);
                    const path = [
                        this.ensureChecksum(tokenInData.address!),
                        this.ensureChecksum(this.wethAddress!),
                        this.ensureChecksum(tokenOutData.address!)
                    ];
                    tx = await this.swapContract.swapExactTokensForTokens(
                        amountIn,
                        amountOutMin,
                        path,
                        this.wallet.address,
                        deadline,
                        { gasLimit: 300000, nonce }
                    );
                }

                const receipt = await tx.wait();
                return receipt;

            } catch (error: any) {
                if (error.message.includes("nonce too low") || error.message.includes("already known")) {
                    retryCount += 1;
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    continue;
                }
                throw error;
            }
        }
        throw new Error("Failed to swap after several attempts");
    }

    public async autoSwap() {
        const tokens = Object.keys(RAINMAKR_TOKENS).filter(t => t !== "ETH");
        const count = 1;

        for (let i = 0; i < count; i++) {
            const tokenIn = "ETH";
            const tokenOut = tokens[Math.floor(Math.random() * tokens.length)];
            const amount = 0.01;

            try {
                logMessage(this.currentNum, this.total, `Attempting swap ${tokenIn} → ${tokenOut}`, "info");
                const receipt = await this.swap(tokenIn, tokenOut, amount);
                logMessage(this.currentNum, this.total, `Swap successful! Tx hash: ${receipt.hash}`, "success");
                logMessage(this.currentNum, this.total, `Block explorer: ${this.explorer}${receipt.hash}`, "success");
            } catch (error: any) {
                logMessage(this.currentNum, this.total, `Swap failed: ${error.message}`, "error");
            }
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }

    public async swapAllTokensToETH(): Promise<void> {
        const BASE_TOKEN = "ETH";
        const tokens = Object.keys(RAINMAKR_TOKENS).filter(t => t !== BASE_TOKEN);
        logMessage(this.currentNum, this.total, "Starting to swap all tokens to ETH", "info");
        for (const token of tokens) {
            try {
                const tokenData = RAINMAKR_TOKENS[token as keyof typeof RAINMAKR_TOKENS];
                if (!tokenData.address) {
                    logMessage(this.currentNum, this.total, `Skipping ${token} (no contract address)`, "info");
                    continue;
                }

                const tokenContract = new ethers.Contract(
                    this.ensureChecksum(tokenData.address),
                    ERC20_ABI,
                    this.wallet
                );
                const balance = await tokenContract.balanceOf(this.wallet.address);
                if (balance === BigInt(0)) {
                    logMessage(this.currentNum, this.total, `No ${token} balance to swap`, "info");
                    continue;
                }
                const balanceFormatted = ethers.formatUnits(balance, tokenData.decimals);
                logMessage(this.currentNum, this.total, `Swapping ${balanceFormatted} ${token} to ETH...`, "process")
                const amountToSwap = balance * BigInt(995) / BigInt(1000);
                const amountToSwapFormatted = Number(ethers.formatUnits(amountToSwap, tokenData.decimals));

                const approveTx = await tokenContract.approve(
                    this.swapaddress,
                    amountToSwap,
                    {
                        gasLimit: 100000,
                        maxFeePerGas: (await this.web3.getFeeData()).maxFeePerGas || undefined
                    }
                );
                await approveTx.wait();
                logMessage(this.currentNum, this.total, `Approval succesfulyy : ${this.explorer}${approveTx.hash}`, "success");

                const path = [
                    this.ensureChecksum(tokenData.address),
                    this.ensureChecksum(this.wethAddress!)
                ];

                const swapTx = await this.swapContract.swapExactTokensForETH(
                    amountToSwap,
                    0,
                    path,
                    this.wallet.address,
                    Math.floor(Date.now() / 1000) + 1800,
                    {
                        gasLimit: 300000,
                        maxFeePerGas: (await this.web3.getFeeData()).maxFeePerGas || undefined
                    }
                );

                const swapReceipt = await swapTx.wait();
                logMessage(this.currentNum, this.total, `Swap successfully : ${this.explorer}${swapTx.hash}`, "success");
                logMessage(this.currentNum, this.total, `${amountToSwapFormatted} ${token} → ETH`, "success");
                await new Promise(resolve => setTimeout(resolve, 2000));

            } catch (error: any) {
                logMessage(this.currentNum, this.total, `Failed to swap ${token}: ${error.message}`, "error");
                continue;
            }
        }

        logMessage(this.currentNum, this.total, "All tokens swapped to ETH successfully!", "success");
    }

    private async getTokenInfo(tokenAddress: string): Promise<{ name: string, symbol: string, decimals: number }> {
        const tokenContract = new ethers.Contract(tokenAddress, ERC20_ABI, this.wallet);

        try {
            const [name, symbol, decimals] = await Promise.all([
                tokenContract.name(),
                tokenContract.symbol(),
                tokenContract.decimals()
            ]);

            return { name, symbol, decimals };
        } catch (error) {
            console.warn(`Could not fetch token info for ${tokenAddress}, using default values`);
            return {
                name: `Unknown (${tokenAddress.slice(0, 6)}...)`,
                symbol: `UNKNOWN`,
                decimals: 18
            };
        }
    }

    public async customBuy(tokenAddress: string, amountInETH: number): Promise<void> {
        try {
            const checksumAddress = this.ensureChecksum(tokenAddress);
            const { name, symbol, decimals } = await this.getTokenInfo(checksumAddress);
            const amountInWei = ethers.parseUnits(amountInETH.toString(), 18);
            const deadline = Math.floor(Date.now() / 1000) + 1800;
            const displayAmount = amountInETH.toFixed(6);

            logMessage(this.currentNum, this.total,
                `Buying ${displayAmount} ETH worth of ${name} (${symbol})`,
                "process");

            const path = [
                this.ensureChecksum(this.wethAddress),
                checksumAddress
            ];

            const tx = await this.swapContract.swapExactETHForTokens(
                0,
                path,
                this.wallet.address,
                deadline,
                {
                    value: amountInWei,
                    gasLimit: 300000,
                    maxFeePerGas: (await this.web3.getFeeData()).maxFeePerGas || undefined
                }
            );

            const receipt = await tx.wait();
            logMessage(this.currentNum, this.total, `Buy successful! Tx hash: ${this.explorer}${receipt.hash}`, "success");
            logMessage(this.currentNum, this.total,
                `Successfully bought ${symbol} with ${displayAmount} ETH`,
                "success");

        } catch (error: any) {
            logMessage(this.currentNum, this.total, `Custom buy failed: ${error.message}`, "error");
            throw error;
        }
    }

    public async customSell(tokenAddress: string, amountToSell: number): Promise<void> {
        try {
            const checksumAddress = this.ensureChecksum(tokenAddress);
            const { name, symbol, decimals } = await this.getTokenInfo(checksumAddress);
            const amountInWei = ethers.parseUnits(amountToSell.toString(), decimals);
            const deadline = Math.floor(Date.now() / 1000) + 1800;
            const displayAmount = amountToSell.toFixed(4);
            logMessage(this.currentNum, this.total,
                `Selling ${displayAmount} ${symbol} (${name})`,
                "process");
            const tokenContract = new ethers.Contract(checksumAddress, ERC20_ABI, this.wallet);
            const approveTx = await tokenContract.approve(
                this.swapaddress,
                amountInWei,
                {
                    gasLimit: 100000,
                    maxFeePerGas: (await this.web3.getFeeData()).maxFeePerGas || undefined
                }
            );
            await approveTx.wait();

            const path = [
                checksumAddress,
                this.ensureChecksum(this.wethAddress)
            ];

            const tx = await this.swapContract.swapExactTokensForETH(
                amountInWei,
                0,
                path,
                this.wallet.address,
                deadline,
                {
                    gasLimit: 300000,
                    maxFeePerGas: (await this.web3.getFeeData()).maxFeePerGas || undefined
                }
            );

            const receipt = await tx.wait();
            logMessage(this.currentNum, this.total, `Sell successful! Tx hash: ${this.explorer}${receipt.hash}`, "success");
            logMessage(this.currentNum, this.total, `Successfully sold ${displayAmount} ${symbol}`, "success");

        } catch (error: any) {
            logMessage(this.currentNum, this.total, `Custom sell failed: ${error.message}`, "error");
            throw error;
        }
    }

    public async sellAllToken(tokenAddress: string): Promise<void> {
        try {
            const checksumAddress = this.ensureChecksum(tokenAddress);
            const tokenContract = new ethers.Contract(checksumAddress, ERC20_ABI, this.wallet);
            const { symbol, decimals } = await this.getTokenInfo(checksumAddress);
            const balance = await tokenContract.balanceOf(this.wallet.address);
            if (balance === BigInt(0)) {
                logMessage(this.currentNum, this.total, `No ${symbol} balance to sell`, "info");
                return;
            }

            const amountToSell = balance * BigInt(995) / BigInt(1000);
            const amountToSellFormatted = parseFloat(ethers.formatUnits(amountToSell, decimals));

            await this.customSell(tokenAddress, amountToSellFormatted);
        } catch (error: any) {
            logMessage(this.currentNum, this.total, `Sell all failed: ${error.message}`, "error");
            throw error;
        }
    }

    public async buyAndSellRandomToken(amountInETH: number = 0.01): Promise<void> {
        try {
            const randomToken = await this.getBuyableTokenTrending();
            if (!randomToken?.contractAddress) {
                logMessage(this.currentNum, this.total, "No valid trending token found", "error");
                return;
            }

            const tokenAddress = randomToken.contractAddress;
            const tokenSymbol = randomToken.symbol || "UNKNOWN";

            logMessage(this.currentNum, this.total, `Selected random token: ${tokenSymbol} (${tokenAddress.slice(0, 6)}...)`, "info");

            await this.customBuy(tokenAddress, amountInETH);
            await new Promise(resolve => setTimeout(resolve, 5000));
            await this.sellAllToken(tokenAddress);

            logMessage(this.currentNum, this.total, `Successfully bought and sold ${tokenSymbol}`, "success");

        } catch (error: any) {
            logMessage(this.currentNum, this.total, `Buy/sell cycle failed: ${error.message}`, "error");
        }
    }

    private async getBuyableTokenTrending(): Promise<{ contractAddress: string, symbol: string } | null> {
        const url = "https://rain-ai.rainmakr.xyz/api/token?page=1&limit=100&mainFilterToken=TRENDING";

        try {
            const response = await this.makeRequest("GET", url);
            if (!response?.data?.data?.length) {
                logMessage(this.currentNum, this.total, "No trending tokens in API response", "warning");
                return null;
            }

            const buyableTokens = response.data.data.filter((token: any) => {
                return (
                    token?.contractAddress &&
                    ethers.isAddress(token.contractAddress) &&
                    token?.progressToListDex === 100 &&
                    parseInt(token?.numberHolder || "0") > 50 &&
                    parseFloat(token?.price || "0") > 0 &&
                    token?.decimal === 18
                );
            });

            if (!buyableTokens.length) {
                logMessage(this.currentNum, this.total,
                    "No tokens meet buyability criteria",
                    "warning");
                return null;
            }

            const randomIndex = Math.floor(Math.random() * buyableTokens.length);
            const selected = buyableTokens[randomIndex];

            return {
                contractAddress: selected.contractAddress,
                symbol: selected.symbol || "UNKNOWN"
            };

        } catch (error: any) {
            logMessage(this.currentNum, this.total, `API Error: ${error.message}`, "error");
            return null;
        }
    }

    public async buyAndSellRandomTokenTopMcap(amountInETH: number = 0.01): Promise<void> {
        try {
            const randomToken = await this.getBuyableTokenTopMcap();
            if (!randomToken?.contractAddress) {
                logMessage(this.currentNum, this.total, "No valid trending token found", "error");
                return;
            }

            const tokenAddress = randomToken.contractAddress;
            const tokenSymbol = randomToken.symbol || "UNKNOWN";

            logMessage(this.currentNum, this.total, `Selected random token: ${tokenSymbol} (${tokenAddress.slice(0, 6)}...)`, "info");

            await this.customBuy(tokenAddress, amountInETH);
            await new Promise(resolve => setTimeout(resolve, 5000));
            await this.sellAllToken(tokenAddress);

            logMessage(this.currentNum, this.total, `Successfully bought and sold ${tokenSymbol}`, "success");

        } catch (error: any) {
            logMessage(this.currentNum, this.total, `Buy/sell cycle failed: ${error.message}`, "error");
        }
    }

    private async getBuyableTokenTopMcap(): Promise<{ contractAddress: string, symbol: string } | null> {
        const url = "https://rain-ai.rainmakr.xyz/api/token?page=1&limit=100&mainFilterToken=TOP_MARKET_CAP";

        try {
            const response = await this.makeRequest("GET", url);
            if (!response?.data?.data?.length) {
                logMessage(this.currentNum, this.total, "No trending tokens in API response", "warning");
                return null;
            }

            const buyableTokens = response.data.data.filter((token: any) => {
                return (
                    token?.contractAddress &&
                    ethers.isAddress(token.contractAddress) &&
                    token?.progressToListDex === 100 &&
                    parseInt(token?.numberHolder || "0") > 50 &&
                    parseFloat(token?.price || "0") > 0 &&
                    token?.decimal === 18
                );
            });

            if (!buyableTokens.length) {
                logMessage(this.currentNum, this.total,
                    "No tokens meet buyability criteria",
                    "warning");
                return null;
            }

            const randomIndex = Math.floor(Math.random() * buyableTokens.length);
            const selected = buyableTokens[randomIndex];

            return {
                contractAddress: selected.contractAddress,
                symbol: selected.symbol || "UNKNOWN"
            };

        } catch (error: any) {
            logMessage(this.currentNum, this.total, `API Error: ${error.message}`, "error");
            return null;
        }
    }
}