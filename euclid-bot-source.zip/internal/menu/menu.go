package menu

import (
	"bufio"
	"euclid-bot/internal/config"
	"euclid-bot/internal/utils"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/fatih/color"
)

type MenuHandler struct {
	reader     *bufio.Reader
	cfg        *config.ConfigHandler
	configMenu *ConfigMenu
}

func (m *MenuHandler) EditConfig() {
	m.configMenu.ShowConfigMenu()
}

func NewMenuHandler() *MenuHandler {
	cfgHandler := config.NewConfigHandler("config.json")
	return &MenuHandler{
		reader:     bufio.NewReader(os.Stdin),
		cfg:        cfgHandler,
		configMenu: NewConfigMenu(cfgHandler),
	}
}

func (m *MenuHandler) ShowMainMenu(version string) {
	m.showBanner(version)

	cfg, err := m.cfg.LoadConfig()
	if err != nil {
		utils.LogMessage(0, 0, "Failed to load config: "+err.Error(), "error")
		time.Sleep(2 * time.Second)
		return
	}

	if len(cfg.Wallets) == 0 {
		if err := m.configMenu.RunFirstTimeSetup(); err != nil {
			utils.LogMessage(0, 0, "Setup failed: "+err.Error(), "error")
			time.Sleep(2 * time.Second)
			return
		}
	}

	for {
		choice := m.showMenuOptions()
		switch choice {
		case "1":
			m.runSingleAccountMode()
			m.showBanner(version)
		case "2":
			m.RunMultiAccountMode()
			m.showBanner(version)
		case "3":
			m.EditConfig()
			m.showBanner(version)
		case "4":
			m.ShowFileInfo()
			m.showBanner(version)
		case "5":
			os.Exit(0)
		default:
			utils.LogMessage(0, 0, "Invalid choice", "error")
		}
	}
}

func (m *MenuHandler) showBanner(version string) {
	banner := `
░█▀▀░█░█░█▀▀░█░░░▀█▀░█▀▄
░█▀▀░█░█░█░░░█░░░░█░░█░█
░▀▀▀░▀▀▀░▀▀▀░▀▀▀░▀▀▀░▀▀░
By : El Puqus Airdrop
github.com/ahlulmukh
Use it at your own risk
`
	color.HiCyan(banner)
	fmt.Print(color.HiGreenString("\nVersion: %s\n", version))
}

func (m *MenuHandler) showMenuOptions() string {
	fmt.Println(color.CyanString("\nMain Menu:"))
	fmt.Println(color.HiGreenString("1. Single Account"))
	fmt.Println(color.YellowString("2. Multi Account"))
	fmt.Println(color.HiBlueString("3. Edit Config"))
	fmt.Println(color.MagentaString("4. Information"))
	fmt.Println(color.RedString("5. Exit"))
	fmt.Print(color.HiCyanString("Enter your choice (1-5): "))

	choice, _ := m.reader.ReadString('\n')
	return strings.TrimSpace(choice)
}

func (m *MenuHandler) ShowFileInfo() {
	//utils.ClearScreen()
	fmt.Println(color.CyanString("\nFile Information:"))

	m.waitForEnter()
}

func (m *MenuHandler) displayMenuBaseSepolia() string {
	//utils.ClearScreen()
	fmt.Println(color.CyanString("\nBase Sepolia :"))
	fmt.Println(color.HiGreenString("1. ETH -> STT"))
	fmt.Println(color.HiGreenString("2. ETH -> BERA"))
	fmt.Println(color.HiGreenString("3. ETH -> MON"))
	fmt.Println(color.HiGreenString("4. ETH -> BNB"))
	fmt.Println(color.RedString("5. Back"))
	fmt.Print(color.HiCyanString("\nChoose mode (1-5): "))

	choice, _ := m.reader.ReadString('\n')
	return strings.TrimSpace(choice)
}

func (m *MenuHandler) displayMenuEthSepolia() string {
	//utils.ClearScreen()
	fmt.Println(color.CyanString("\nETH Sepolia :"))
	fmt.Println(color.HiGreenString("1. ETH -> MON"))
	fmt.Println(color.RedString("2. Back"))
	fmt.Print(color.HiCyanString("\nChoose mode (1-2): "))

	choice, _ := m.reader.ReadString('\n')
	return strings.TrimSpace(choice)
}

func (m *MenuHandler) waitForEnter() {
	fmt.Print("Press Enter to continue...")
	m.reader.ReadBytes('\n')
}

func (m *MenuHandler) displaySingleAccountMainMenu() string {
	//utils.ClearScreen()
	fmt.Println(color.CyanString("\nSingle Account Menu:"))
	fmt.Println(color.HiGreenString("1. Base Sepolia"))
	fmt.Println(color.HiGreenString("2. ETH Sepolia"))
	fmt.Println(color.HiYellowString("3. Check Profile"))
	fmt.Println(color.RedString("4. Back to Main Menu"))
	fmt.Print(color.HiCyanString("\nChoose option (1-4): "))

	choice, _ := m.reader.ReadString('\n')
	return strings.TrimSpace(choice)
}
