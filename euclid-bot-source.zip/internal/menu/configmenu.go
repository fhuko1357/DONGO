package menu

import (
	"bufio"
	"euclid-bot/internal/config"
	"euclid-bot/internal/utils"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/ethereum/go-ethereum/crypto"
	"github.com/fatih/color"
)

type ConfigMenu struct {
	reader *bufio.Reader
	cfg    *config.ConfigHandler
}

func NewConfigMenu(cfg *config.ConfigHandler) *ConfigMenu {
	return &ConfigMenu{
		reader: bufio.NewReader(os.Stdin),
		cfg:    cfg,
	}
}

func (cm *ConfigMenu) ShowConfigMenu() {
	for {
		utils.ClearScreen()
		fmt.Println(color.CyanString("\nCONFIGURATION MENU"))
		fmt.Println(color.GreenString("1. Manage Wallets"))
		fmt.Println(color.YellowString("2. Set Transaction Delays"))
		fmt.Println(color.HiBlueString("3. View Current Config"))
		fmt.Println(color.RedString("4. Back to Main Menu"))
		fmt.Print(color.HiCyanString("Choose option (1-4): "))

		choice, _ := cm.reader.ReadString('\n')
		choice = strings.TrimSpace(choice)

		switch choice {
		case "1":
			cm.manageWallets()
		case "2":
			cm.setTransactionDelays()
		case "3":
			cm.viewCurrentConfig()
		case "4":
			return
		default:
			utils.LogMessage(0, 0, "Invalid option", "error")
			time.Sleep(1 * time.Second)
		}
	}
}

func (cm *ConfigMenu) manageWallets() {
	for {
		utils.ClearScreen()
		cfg, err := cm.cfg.LoadConfig()
		if err != nil {
			utils.LogMessage(0, 0, "Failed to load config: "+err.Error(), "error")
			return
		}

		fmt.Println(color.CyanString("\n🔑 WALLET MANAGEMENT"))
		fmt.Printf(color.GreenString("Current wallets: %d\n\n"), len(cfg.Wallets))
		for i, wallet := range cfg.Wallets {
			pk, err := crypto.HexToECDSA(wallet.PrivateKey)
			if err != nil {
				continue
			}
			addr := crypto.PubkeyToAddress(pk.PublicKey).Hex()

			var babylonAddr string
			if wallet.BabylonAddress != nil {
				babylonAddr = *wallet.BabylonAddress
			} else {
				babylonAddr = "No address"
			}

			fmt.Printf("%d. ETH: %s...%s | Babylon: %s...%s\n",
				i+1,
				addr[:6],
				addr[len(addr)-4:],
				babylonAddr[:6],
				babylonAddr[len(babylonAddr)-4:],
			)
		}

		fmt.Println(color.YellowString("\n1. Add New Wallet"))
		fmt.Println(color.RedString("2. Remove Wallet"))
		fmt.Println(color.BlueString("3. Back"))
		fmt.Print(color.HiCyanString("Choose option (1-3): "))

		choice, _ := cm.reader.ReadString('\n')
		choice = strings.TrimSpace(choice)

		switch choice {
		case "1":
			cm.addWallet()
		case "2":
			cm.removeWallet()
		case "3":
			return
		default:
			utils.LogMessage(0, 0, "Invalid option", "error")
		}
	}
}

func (cm *ConfigMenu) addWallet() {
	fmt.Print("\nEnter private key (with or without 0x prefix): ")
	pk, _ := cm.reader.ReadString('\n')
	pk = strings.TrimSpace(pk)

	fmt.Print("Enter Babylon address: ")
	babylonAddr, _ := cm.reader.ReadString('\n')
	babylonAddr = strings.TrimSpace(babylonAddr)

	if err := cm.cfg.AddWallet(pk, babylonAddr); err != nil {
		utils.LogMessage(0, 0, "Failed to add wallet: "+err.Error(), "error")
	} else {
		pkObj, err := crypto.HexToECDSA(strings.TrimPrefix(pk, "0x"))
		if err == nil {
			addr := crypto.PubkeyToAddress(pkObj.PublicKey).Hex()
			utils.LogMessage(0, 0, fmt.Sprintf("Added wallet - ETH: %s | Babylon: %s", addr, babylonAddr), "success")
		} else {
			utils.LogMessage(0, 0, "Wallet added successfully", "success")
		}
	}
	time.Sleep(2 * time.Second)
}

func (cm *ConfigMenu) removeWallet() {
	cfg, err := cm.cfg.LoadConfig()
	if err != nil {
		utils.LogMessage(0, 0, "Failed to load config: "+err.Error(), "error")
		return
	}

	if len(cfg.Wallets) == 0 {
		utils.LogMessage(0, 0, "No wallets to remove", "warning")
		return
	}

	fmt.Print("\nEnter wallet index to remove (1-", len(cfg.Wallets), "): ")
	indexStr, _ := cm.reader.ReadString('\n')
	index, err := strconv.Atoi(strings.TrimSpace(indexStr))
	if err != nil || index < 1 || index > len(cfg.Wallets) {
		utils.LogMessage(0, 0, "Invalid index", "error")
		return
	}

	if err := cm.cfg.RemoveWallet(index - 1); err != nil {
		utils.LogMessage(0, 0, "Failed to remove wallet: "+err.Error(), "error")
	} else {
		utils.LogMessage(0, 0, "Wallet removed successfully", "success")
	}
	time.Sleep(2 * time.Second)
}

func (cm *ConfigMenu) setTransactionDelays() {
	cfg, _ := cm.cfg.LoadConfig()

	fmt.Printf("\nCurrent delays: Min %s - Max %s\n", cfg.MinDelay, cfg.MaxDelay)
	fmt.Print("Enter new minimum delay (seconds): ")
	minStr, _ := cm.reader.ReadString('\n')
	min, _ := strconv.Atoi(strings.TrimSpace(minStr))

	fmt.Print("Enter new maximum delay (seconds): ")
	maxStr, _ := cm.reader.ReadString('\n')
	max, _ := strconv.Atoi(strings.TrimSpace(maxStr))

	if err := cm.cfg.SetDelayRange(
		time.Duration(min)*time.Second,
		time.Duration(max)*time.Second,
	); err != nil {
		utils.LogMessage(0, 0, "Failed to set delays: "+err.Error(), "error")
	} else {
		utils.LogMessage(0, 0, "Delays updated successfully", "success")
	}
	time.Sleep(2 * time.Second)
}

func (cm *ConfigMenu) viewCurrentConfig() {
	cfg, err := cm.cfg.LoadConfig()
	if err != nil {
		utils.LogMessage(0, 0, "Failed to load config: "+err.Error(), "error")
		return
	}

	utils.ClearScreen()
	fmt.Println(color.CyanString("\n📋 CURRENT CONFIGURATION"))
	fmt.Println(color.GreenString("\nWallets:"))
	for i, wallet := range cfg.Wallets {
		pk, err := crypto.HexToECDSA(wallet.PrivateKey)
		if err != nil {
			continue
		}
		addr := crypto.PubkeyToAddress(pk.PublicKey).Hex()
		fmt.Printf("%d. ETH: %s | Babylon: %s\n", i+1, addr, wallet.BabylonAddress)
	}

	fmt.Println(color.YellowString("\nTransaction Settings:"))
	fmt.Printf("Min Delay: %s\n", cfg.MinDelay)
	fmt.Printf("Max Delay: %s\n", cfg.MaxDelay)

	fmt.Print(color.HiCyanString("\nPress Enter to return..."))
	cm.reader.ReadString('\n')
}

func (cm *ConfigMenu) RunFirstTimeSetup() error {
	color.Yellow("\nWelcome to Euclid Testnet Bot By El Puqus!")
	color.Yellow("Please follow these steps to configure your bot\n")

	if err := cm.addFirstWallet(); err != nil {
		return fmt.Errorf("failed to add wallet: %v", err)
	}

	if err := cm.setInitialDelays(); err != nil {
		return fmt.Errorf("failed to set delays: %v", err)
	}

	_, err := cm.cfg.LoadConfig()
	if err != nil {
		return fmt.Errorf("failed to load final config: %v", err)
	}

	time.Sleep(1 * time.Second)
	return nil
}

func (cm *ConfigMenu) addFirstWallet() error {
	color.Cyan("\n1: Add your first wallet")

	for {
		fmt.Print(color.HiCyanString("Enter private key (with or without 0x prefix): "))
		pk, _ := cm.reader.ReadString('\n')
		pk = strings.TrimSpace(pk)

		color.Cyan("Enter Babylon address (Leave blank to skip): ")
		babylonAddr, _ := cm.reader.ReadString('\n')
		babylonAddr = strings.TrimSpace(babylonAddr)

		var babylonAddrPtr *string
		if babylonAddr != "" {
			babylonAddrPtr = &babylonAddr
		}

		if pk == "" {
			color.Red("Private key cannot be empty")
			continue
		}

		if err := cm.cfg.AddWallet(pk, babylonAddr); err != nil {
			color.Red("Error: %v", err)
			continue
		}

		cfg, err := cm.cfg.LoadConfig()
		if err != nil {
			return err
		}

		pkObj, err := crypto.HexToECDSA(strings.TrimPrefix(cfg.Wallets[0].PrivateKey, "0x"))
		if err != nil {
			return err
		}
		addr := crypto.PubkeyToAddress(pkObj.PublicKey).Hex()
		color.Green("Wallet added successfully!")
		color.Green("ETH Address: %s", addr)

		if babylonAddrPtr != nil {
			color.Green("Babylon Address: %s", *babylonAddrPtr)
		} else {
			color.Green("No Babylon Address provided.")
		}

		return nil
	}
}

func (cm *ConfigMenu) setInitialDelays() error {
	color.Cyan("\nSTEP 2: Set transaction delay settings")

	for {
		fmt.Print(color.HiCyanString("Enter minimum delay between transactions (seconds, default 1): "))
		minStr, _ := cm.reader.ReadString('\n')
		minStr = strings.TrimSpace(minStr)

		var min float64 = 1
		if minStr != "" {
			var err error
			min, err = strconv.ParseFloat(minStr, 64)
			if err != nil || min <= 0 {
				color.Red("Invalid delay value")
				continue
			}
		}

		fmt.Print(color.HiCyanString("Enter maximum delay between transactions (seconds, default 3): "))
		maxStr, _ := cm.reader.ReadString('\n')
		maxStr = strings.TrimSpace(maxStr)

		var max float64 = 3
		if maxStr != "" {
			var err error
			max, err = strconv.ParseFloat(maxStr, 64)
			if err != nil || max <= 0 {
				color.Red("Invalid delay value")
				continue
			}
		}

		if min > max {
			color.Red("Minimum delay cannot be greater than maximum")
			continue
		}

		err := cm.cfg.SetDelayRange(
			time.Duration(min*float64(time.Second)),
			time.Duration(max*float64(time.Second)),
		)
		if err != nil {
			return err
		}

		color.Green("Transaction delays set to %.1f-%.1f seconds", min, max)
		return nil
	}
}
