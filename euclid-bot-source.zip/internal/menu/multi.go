package menu

import (
	"context"
	"crypto/ecdsa"
	"euclid-bot/internal/bridgesepoila"
	"euclid-bot/internal/chain"
	"euclid-bot/internal/pkg/ethclient"
	"euclid-bot/internal/proxy"
	"euclid-bot/internal/utils"
	"fmt"
	"sync"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
)

func (m *MenuHandler) RunMultiAccountMode() {
	for {
		privateKeys, err := m.cfg.LoadPrivateKeys()
		if err != nil {
			utils.LogMessage(0, 0, fmt.Sprintf("Failed to load private keys: %v", err), "error")
			return
		}

		modeChoice := m.displayMenuBaseSepolia()

		switch modeChoice {
		case "1":
			fmt.Print("amount in ETH (e.g. 0.01): ")
			var amount string
			fmt.Scanln(&amount)
			m.processMultiEthBase(privateKeys, amount)
		default:
			utils.LogMessage(0, 0, "Invalid menu selected.", "warning")
		}
	}
}

func (m *MenuHandler) processMultiEthBase(keys []*ecdsa.PrivateKey, amountIn string) {
	var wg sync.WaitGroup
	errorChan := make(chan error, len(keys))

	for i, privateKey := range keys {
		wg.Add(1)

		go func(idx int, pk *ecdsa.PrivateKey) {
			defer wg.Done()
			baseConfig := utils.Networks["basesepolia"]
			proxy.LoadProxies()
			proxy, err := proxy.GetRandomProxy(1, 1)
			if err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Failed to get proxy: %v", err), "error")
				return
			}

			client, err := ethclient.New(context.Background(), baseConfig.RPC, proxy)
			if err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Failed to create Ethereum client: %v", err), "error")
				return
			}
			defer client.Close()

			chainID, err := client.ChainID(context.Background())
			if err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Failed to get chain ID: %v", err), "error")
				return
			}

			senderAddress := crypto.PubkeyToAddress(privateKey.PublicKey).Hex()
			amountWei := utils.EtherToWei(amountIn)
			baseSvc, err := chain.NewApiBase()
			if err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Failed to create BaseSepolia service: %v", err), "error")
				return
			}

			utils.LogMessage(0, 0, "Getting swap data from API...", "process")
			swapData, err := baseSvc.ExecuteSwap(
				context.Background(),
				amountWei.String(),
				senderAddress,
				"0",
				senderAddress,
				senderAddress,
			)
			if err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Failed to get swap data: %v", err), "error")
				return
			}

			swapResponse, ok := swapData.(*utils.SwapResponse)
			if !ok || len(swapResponse.Msgs) == 0 {
				utils.LogMessage(0, 0, "Invalid swap response", "error")
				return
			}

			bridgeSvc, err := bridgesepoila.NewService(client, common.HexToAddress(swapResponse.Contract), chainID)
			if err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Failed to create bridge service: %v", err), "error")
				return
			}

			utils.LogMessage(0, 0, "Sending swap transaction...", "process")
			signedTx, err := bridgeSvc.SendTransaction(
				privateKey,
				chainID,
				swapResponse.Msgs[0].To,
				swapResponse.Msgs[0].Data,
				swapResponse.Msgs[0].Value,
			)
			if err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Failed to send swap transaction: %v", err), "error")
				return
			}

			if signedTx == nil {
				utils.LogMessage(0, 0, "Signed transaction is nil", "error")
				return
			}

			utils.LogMessage(0, 0, "Swap transaction sent successfully!", "success")
			utils.LogMessage(0, 0, fmt.Sprintf("Tx hash: %s", signedTx.Hash().Hex()), "success")
			utils.LogMessage(0, 0, fmt.Sprintf("Explorer: %s/tx/%s", baseConfig.Explorer, signedTx.Hash().Hex()), "success")

			tracker, err := chain.NewTracker()
			if err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Failed to create tracker: %v", err), "warning")
				return
			}

			utils.LogMessage(0, 0, "Tracking transaction...", "process")
			if err := tracker.TrackSwap(
				context.Background(),
				"base",
				signedTx.Hash().Hex(),
				crypto.PubkeyToAddress(privateKey.PublicKey).Hex(),
				"EUCLIDEAN278284",
			); err != nil {
				utils.LogMessage(0, 0, fmt.Sprintf("Tracking error: %v", err), "warning")
			}

		}(i, privateKey)
	}

	go func() {
		wg.Wait()
		close(errorChan)
	}()

	for err := range errorChan {
		utils.LogMessage(0, 0, err.Error(), "error")
	}

	utils.LogMessage(0, 0, "All complete!", "success")
}
