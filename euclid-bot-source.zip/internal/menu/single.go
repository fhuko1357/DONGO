package menu

import (
	"crypto/ecdsa"
	"euclid-bot/internal/chain"
	"euclid-bot/internal/utils"
	"fmt"
	"os"
	"time"

	"github.com/ethereum/go-ethereum/crypto"
	"github.com/fatih/color"
)

func (m *MenuHandler) runSingleAccountMode() {
	privateKeys, err := m.cfg.LoadPrivateKeys()
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to load private keys: %v", err), "error")
		return
	}
	selectedIndex := m.selectAccount(privateKeys)
	privateKey := privateKeys[selectedIndex]

	for {
		choice := m.displaySingleAccountMainMenu()
		switch choice {
		case "1":
			m.processBaseSepoliaMenu(privateKey)
		case "2":
			m.processEthSepoliaMenu(privateKey)
		case "3":
			m.checkUserProfile(privateKey)
		case "4":
			return
		default:
			utils.LogMessage(0, 0, "Invalid choice", "error")
		}
	}
}

func (m *MenuHandler) selectAccount(keys []*ecdsa.PrivateKey) int {
	color.Cyan("\nAccount Ready:")
	for i, key := range keys {
		addr := crypto.PubkeyToAddress(key.PublicKey).Hex()
		fmt.Printf("%d. %s\n", i+1, addr)
	}

	fmt.Print("\nChoose account (1-", len(keys), "): ")
	var choice int
	_, err := fmt.Scanln(&choice)
	if err != nil || choice < 1 || choice > len(keys) {
		utils.LogMessage(0, 0, "Invalid choice", "error")
		os.Exit(1)
	}
	return choice - 1
}

func (m *MenuHandler) proccessBaseAccount(privateKey *ecdsa.PrivateKey, option string) {
	switch option {
	case "1":
		fmt.Print("how many tx ? : ")
		var count int
		fmt.Scanln(&count)
		fmt.Print("amount in ETH (e.g. 0.01): ")
		var amount string
		fmt.Scanln(&amount)
		fmt.Print("referral code: ")
		var reffcode string
		fmt.Scanln(&reffcode)

		for i := 0; i < count; i++ {
			utils.LogMessage(0, 0, fmt.Sprintf("Swap %d/%d...", i+1, count), "process")
			chain.ProcessETHSwap(privateKey, amount, "stt", m.cfg, reffcode)
			if i < count-1 {
				delay := m.cfg.GetRandomDelay()
				utils.LogMessage(0, 0, fmt.Sprintf("Waiting %s before next swap...", delay), "info")
				time.Sleep(delay)
			}
		}
	case "2":
		fmt.Print("how many tx ? : ")
		var count int
		fmt.Scanln(&count)
		fmt.Print("amount in ETH (e.g. 0.01): ")
		var amount string
		fmt.Scanln(&amount)
		fmt.Print("referral code: ")
		var reffcode string
		fmt.Scanln(&reffcode)

		for i := 0; i < count; i++ {
			utils.LogMessage(0, 0, fmt.Sprintf("Swap %d/%d...", i+1, count), "process")
			chain.ProcessETHSwap(privateKey, amount, "bera", m.cfg, reffcode)
			if i < count-1 {
				delay := m.cfg.GetRandomDelay()
				utils.LogMessage(0, 0, fmt.Sprintf("Waiting %s before next swap...", delay), "info")
				time.Sleep(delay)
			}
		}
	case "3":
		fmt.Print("how many tx ? : ")
		var count int
		fmt.Scanln(&count)
		fmt.Print("amount in ETH (e.g. 0.01): ")
		var amount string
		fmt.Scanln(&amount)
		fmt.Print("referral code: ")
		var reffcode string
		fmt.Scanln(&reffcode)

		for i := 0; i < count; i++ {
			utils.LogMessage(0, 0, fmt.Sprintf("Swap %d/%d...", i+1, count), "process")
			chain.ProcessETHSwap(privateKey, amount, "mon", m.cfg, reffcode)
			if i < count-1 {
				delay := m.cfg.GetRandomDelay()
				utils.LogMessage(0, 0, fmt.Sprintf("Waiting %s before next swap...", delay), "info")
				time.Sleep(delay)
			}
		}
	case "4":
		fmt.Print("how many tx ? : ")
		var count int
		fmt.Scanln(&count)
		fmt.Print("amount in ETH (e.g. 0.01): ")
		var amount string
		fmt.Scanln(&amount)
		fmt.Print("referral code: ")
		var reffcode string
		fmt.Scanln(&reffcode)
		for i := 0; i < count; i++ {
			utils.LogMessage(0, 0, fmt.Sprintf("Swap %d/%d...", i+1, count), "process")
			chain.ProcessETHSwap(privateKey, amount, "bnb", m.cfg, reffcode)
			if i < count-1 {
				delay := m.cfg.GetRandomDelay()
				utils.LogMessage(0, 0, fmt.Sprintf("Waiting %s before next swap...", delay), "info")
				time.Sleep(delay)
			}
		}
	default:
		utils.LogMessage(0, 0, "Invalid choice", "error")
	}
}

func (m *MenuHandler) processBaseSepoliaMenu(privateKey *ecdsa.PrivateKey) {
	for {
		modeChoice := m.displayMenuBaseSepolia()
		switch modeChoice {
		case "1", "2", "3", "4":
			m.proccessBaseAccount(privateKey, modeChoice)
		case "5":
			return
		default:
			utils.LogMessage(0, 0, "Invalid choice", "error")
		}
	}
}

func (m *MenuHandler) proccessEthAccount(privateKey *ecdsa.PrivateKey, option string) {
	switch option {
	case "1":
		fmt.Print("how many tx ? : ")
		var count int
		fmt.Scanln(&count)
		fmt.Print("amount in ETH (e.g. 0.01): ")
		var amount string
		fmt.Scanln(&amount)
		fmt.Print("referral code: ")
		var reffcode string
		fmt.Scanln(&reffcode)

		for i := 0; i < count; i++ {
			utils.LogMessage(0, 0, fmt.Sprintf("Swap %d/%d...", i+1, count), "process")
			chain.ProcessETHSepoliaSwap(privateKey, amount, "mon", m.cfg, reffcode)
			if i < count-1 {
				delay := m.cfg.GetRandomDelay()
				utils.LogMessage(0, 0, fmt.Sprintf("Waiting %s before next swap...", delay), "info")
				time.Sleep(delay)
			}
		}
	default:
		utils.LogMessage(0, 0, "Invalid choice", "error")
	}
}

func (m *MenuHandler) processEthSepoliaMenu(privateKey *ecdsa.PrivateKey) {
	for {
		modeChoice := m.displayMenuEthSepolia()
		switch modeChoice {
		case "1":
			m.proccessEthAccount(privateKey, modeChoice)
		case "2":
			return
		default:
			utils.LogMessage(0, 0, "Invalid choice", "error")
		}
	}
}

func (m *MenuHandler) checkUserProfile(privateKey *ecdsa.PrivateKey) {
	address := crypto.PubkeyToAddress(privateKey.PublicKey).Hex()

	utils.LogMessage(0, 0, fmt.Sprintf("Checking profile for address: %s", address), "info")

	checkUser, err := chain.NewCheckUser()
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to create check user client: %v", err), "error")
		m.waitForEnter()
		return
	}

	user, err := checkUser.GetUserStats(address)
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to get user stats: %v", err), "error")
		m.waitForEnter()
		return
	}

	fmt.Println(color.CyanString("\nUser Profile:"))
	fmt.Println(color.HiGreenString("Name: %s", user.Name))
	fmt.Println(color.HiGreenString("Passport ID: %s", user.PassportID))
	fmt.Println(color.HiGreenString("Rank: %d", user.Rank))
	fmt.Println(color.HiGreenString("Total Transactions: %d", user.TotalTxns))
	fmt.Println(color.HiGreenString("Total Volume: %.4f", user.TotalVolume))
	fmt.Println(color.HiGreenString("Wallet Address: %s", user.WalletAddress))

	m.waitForEnter()
}
