package token

import (
	"context"
	"crypto/ecdsa"
	"fmt"
	"math/big"

	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
)

type Service struct {
	contract *Token
	client   bind.ContractBackend
	chainID  *big.Int
}

func NewService(client bind.ContractBackend, contractAddress common.Address, chainID *big.Int) (*Service, error) {
	contract, err := NewToken(contractAddress, client)
	if err != nil {
		return nil, fmt.Errorf("failed to create token contract: %w", err)
	}

	return &Service{
		contract: contract,
		client:   client,
		chainID:  chainID,
	}, nil
}

func (s *Service) BalanceOf(account common.Address) (*big.Int, error) {
	return s.contract.BalanceOf(&bind.CallOpts{Context: context.Background()}, account)
}

func (s *Service) Approve(privateKey *ecdsa.PrivateKey, chainID *big.Int, spender common.Address, amount *big.Int) (*types.Transaction, error) {
	auth, err := bind.NewKeyedTransactorWithChainID(privateKey, chainID)
	if err != nil {
		return nil, fmt.Errorf("failed to create transactor: %w", err)
	}

	return s.contract.Approve(auth, spender, amount)
}
