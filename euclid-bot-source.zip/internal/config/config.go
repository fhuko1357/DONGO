package config

import (
	"bufio"
	"crypto/ecdsa"
	"encoding/json"
	"fmt"
	"math/rand/v2"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/ethereum/go-ethereum/crypto"
	"github.com/fatih/color"
)

const (
	DefaultConfigFile = "config.json"
	DefaultMinDelay   = 1 * time.Second
	DefaultMaxDelay   = 3 * time.Second
)

type Wallet struct {
	PrivateKey     string  `json:"private_keys"`
	BabylonAddress *string `json:"babylonAddress"`
}

type Config struct {
	Wallets  []Wallet      `json:"wallet"`
	MinDelay time.Duration `json:"min_delay"`
	MaxDelay time.Duration `json:"max_delay"`
}

type ConfigHandler struct {
	configFile string
	reader     *bufio.Reader
}

func NewConfigHandler(configFile string) *ConfigHandler {
	if configFile == "" {
		configFile = DefaultConfigFile
	}
	return &ConfigHandler{
		configFile: configFile,
		reader:     bufio.NewReader(os.Stdin),
	}
}

func (ch *ConfigHandler) LoadConfig() (*Config, error) {
	file, err := os.ReadFile(ch.configFile)
	if err != nil {
		if os.IsNotExist(err) {
			return &Config{
				Wallets:  []Wallet{},
				MinDelay: DefaultMinDelay,
				MaxDelay: DefaultMaxDelay,
			}, nil
		}
		return nil, fmt.Errorf("failed to read config file: %v", err)
	}

	var cfg Config
	if err := json.Unmarshal(file, &cfg); err != nil {
		return nil, fmt.Errorf("failed to parse config file: %v", err)
	}

	if cfg.MinDelay == 0 {
		cfg.MinDelay = DefaultMinDelay
	}
	if cfg.MaxDelay == 0 {
		cfg.MaxDelay = DefaultMaxDelay
	}

	return &cfg, nil
}

func (ch *ConfigHandler) InitializeConfig() error {
	if _, err := os.Stat(ch.configFile); err == nil {
		return nil
	}

	color.Yellow("\nWelcome! Let's set up your initial configuration")

	cfg := &Config{
		Wallets:  []Wallet{},
		MinDelay: DefaultMinDelay,
		MaxDelay: DefaultMaxDelay,
	}

	color.Cyan("\nStep 1: Add your first wallet")
	wallet, err := ch.promptWallet()
	if err != nil {
		return err
	}
	cfg.Wallets = append(cfg.Wallets, *wallet)

	color.Cyan("\nStep 2: Set transaction delay range (in seconds)")
	minDelay, maxDelay, err := ch.promptDelayRange()
	if err != nil {
		return err
	}
	cfg.MinDelay = minDelay
	cfg.MaxDelay = maxDelay
	if err := ch.SaveConfig(cfg); err != nil {
		return err
	}

	color.Green("\nConfiguration successfully created at %s", ch.configFile)
	return nil
}

func (ch *ConfigHandler) promptWallet() (*Wallet, error) {
	for {
		color.Cyan("Enter private key (with or without 0x prefix): ")
		pk, _ := ch.reader.ReadString('\n')
		pk = strings.TrimSpace(pk)
		pk = remove0xPrefix(pk)

		if _, err := crypto.HexToECDSA(pk); err != nil {
			color.Red("Invalid private key: %v", err)
			continue
		}

		color.Cyan("Enter Babylon address (press Enter to skip): ")
		babylonAddr, _ := ch.reader.ReadString('\n')
		babylonAddr = strings.TrimSpace(babylonAddr)

		var babylonAddrPtr *string
		if babylonAddr != "" {
			babylonAddrPtr = &babylonAddr
		}

		return &Wallet{
			PrivateKey:     pk,
			BabylonAddress: babylonAddrPtr,
		}, nil
	}
}

func (ch *ConfigHandler) promptDelayRange() (time.Duration, time.Duration, error) {
	for {
		color.Cyan("Enter minimum delay (default %.1f seconds): ", DefaultMinDelay.Seconds())
		minStr, _ := ch.reader.ReadString('\n')
		minStr = strings.TrimSpace(minStr)

		var min float64
		var err error
		if minStr == "" {
			min = DefaultMinDelay.Seconds()
		} else {
			min, err = strconv.ParseFloat(minStr, 64)
			if err != nil {
				color.Red("Invalid number: %v", err)
				continue
			}
		}

		color.Cyan("Enter maximum delay (default %.1f seconds): ", DefaultMaxDelay.Seconds())
		maxStr, _ := ch.reader.ReadString('\n')
		maxStr = strings.TrimSpace(maxStr)

		var max float64
		if maxStr == "" {
			max = DefaultMaxDelay.Seconds()
		} else {
			max, err = strconv.ParseFloat(maxStr, 64)
			if err != nil {
				color.Red("Invalid number: %v", err)
				continue
			}
		}

		if min <= 0 || max <= 0 {
			color.Red("Delays must be positive numbers")
			continue
		}
		if min > max {
			color.Red("Minimum delay cannot be greater than maximum")
			continue
		}

		return time.Duration(min * float64(time.Second)),
			time.Duration(max * float64(time.Second)),
			nil
	}
}

func (ch *ConfigHandler) SaveConfig(cfg *Config) error {
	file, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal config: %v", err)
	}

	if err := os.WriteFile(ch.configFile, file, 0644); err != nil {
		return fmt.Errorf("failed to write config file: %v", err)
	}

	return nil
}

func (ch *ConfigHandler) LoadPrivateKeys() ([]*ecdsa.PrivateKey, error) {
	cfg, err := ch.LoadConfig()
	if err != nil {
		return nil, err
	}

	var keys []*ecdsa.PrivateKey
	for _, wallet := range cfg.Wallets {
		pkHex := remove0xPrefix(wallet.PrivateKey)
		pk, err := crypto.HexToECDSA(pkHex)
		if err != nil {
			return nil, fmt.Errorf("invalid private key: %v", err)
		}
		keys = append(keys, pk)
	}

	if len(keys) == 0 {
		return nil, fmt.Errorf("no private keys found in config")
	}

	return keys, nil
}

func (ch *ConfigHandler) GetBabylonAddress(privateKey []byte) (string, error) {
	cfg, err := ch.LoadConfig()
	if err != nil {
		return "", err
	}

	pkHex := fmt.Sprintf("%x", privateKey)

	for _, wallet := range cfg.Wallets {
		if remove0xPrefix(wallet.PrivateKey) == pkHex {
			if wallet.BabylonAddress != nil {
				return *wallet.BabylonAddress, nil
			}
			return "", fmt.Errorf("babylon address not found for the given private key")
		}
	}

	return "", fmt.Errorf("babylon address not found for the given private key")
}

func (ch *ConfigHandler) AddWallet(privateKey, babylonAddress string) error {
	privateKey = remove0xPrefix(privateKey)

	_, err := crypto.HexToECDSA(privateKey)
	if err != nil {
		return fmt.Errorf("invalid private key: %v", err)
	}

	var babylonAddrPtr *string
	if babylonAddress != "" {
		babylonAddrPtr = &babylonAddress
	}

	cfg, err := ch.LoadConfig()
	if err != nil {
		cfg = &Config{
			Wallets:  []Wallet{},
			MinDelay: DefaultMinDelay,
			MaxDelay: DefaultMaxDelay,
		}
	}

	for _, wallet := range cfg.Wallets {
		if remove0xPrefix(wallet.PrivateKey) == privateKey {
			return fmt.Errorf("private key already exists in config")
		}
	}

	cfg.Wallets = append(cfg.Wallets, Wallet{
		PrivateKey:     privateKey,
		BabylonAddress: babylonAddrPtr,
	})
	return ch.SaveConfig(cfg)
}

func (ch *ConfigHandler) GetRandomDelay() time.Duration {
	cfg, err := ch.LoadConfig()
	if err != nil {
		return DefaultMinDelay + time.Duration(float64(DefaultMaxDelay-DefaultMinDelay)*rand.Float64())
	}

	min := cfg.MinDelay
	max := cfg.MaxDelay
	if min > max {
		min, max = max, min
	}

	return min + time.Duration(float64(max-min)*rand.Float64())
}

func (ch *ConfigHandler) SetDelayRange(min, max time.Duration) error {
	cfg, err := ch.LoadConfig()
	if err != nil {
		return err
	}

	cfg.MinDelay = min
	cfg.MaxDelay = max
	return ch.SaveConfig(cfg)
}

func remove0xPrefix(s string) string {
	if strings.HasPrefix(s, "0x") {
		return s[2:]
	}
	return s
}

func (ch *ConfigHandler) RemoveWallet(index int) error {
	cfg, err := ch.LoadConfig()
	if err != nil {
		return err
	}

	if index < 0 || index >= len(cfg.Wallets) {
		return fmt.Errorf("invalid index")
	}

	cfg.Wallets = append(cfg.Wallets[:index], cfg.Wallets[index+1:]...)
	return ch.SaveConfig(cfg)
}
