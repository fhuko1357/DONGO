// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package bridgesepoila

import (
	"errors"
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = errors.New
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
	_ = abi.ConvertType
)

// Instruction is an auto generated low-level Go binding around an user-defined struct.
type Instruction struct {
	Version uint8
	Opcode  uint8
	Operand []byte
}

// BridgesepoilaMetaData contains all meta data concerning the Bridgesepoila contract.
var BridgesepoilaMetaData = &bind.MetaData{
	ABI: "[{\"inputs\":[{\"internalType\":\"uint32\",\"name\":\"channelId\",\"type\":\"uint32\"},{\"internalType\":\"uint64\",\"name\":\"timeoutHeight\",\"type\":\"uint64\"},{\"internalType\":\"uint64\",\"name\":\"timeoutTimestamp\",\"type\":\"uint64\"},{\"internalType\":\"bytes32\",\"name\":\"salt\",\"type\":\"bytes32\"},{\"components\":[{\"internalType\":\"uint8\",\"name\":\"version\",\"type\":\"uint8\"},{\"internalType\":\"uint8\",\"name\":\"opcode\",\"type\":\"uint8\"},{\"internalType\":\"bytes\",\"name\":\"operand\",\"type\":\"bytes\"}],\"internalType\":\"structInstruction\",\"name\":\"instruction\",\"type\":\"tuple\"}],\"name\":\"send\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"}]",
}

// BridgesepoilaABI is the input ABI used to generate the binding from.
// Deprecated: Use BridgesepoilaMetaData.ABI instead.
var BridgesepoilaABI = BridgesepoilaMetaData.ABI

// Bridgesepoila is an auto generated Go binding around an Ethereum contract.
type Bridgesepoila struct {
	BridgesepoilaCaller     // Read-only binding to the contract
	BridgesepoilaTransactor // Write-only binding to the contract
	BridgesepoilaFilterer   // Log filterer for contract events
}

// BridgesepoilaCaller is an auto generated read-only Go binding around an Ethereum contract.
type BridgesepoilaCaller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// BridgesepoilaTransactor is an auto generated write-only Go binding around an Ethereum contract.
type BridgesepoilaTransactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// BridgesepoilaFilterer is an auto generated log filtering Go binding around an Ethereum contract events.
type BridgesepoilaFilterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// BridgesepoilaSession is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type BridgesepoilaSession struct {
	Contract     *Bridgesepoila    // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// BridgesepoilaCallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type BridgesepoilaCallerSession struct {
	Contract *BridgesepoilaCaller // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts        // Call options to use throughout this session
}

// BridgesepoilaTransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type BridgesepoilaTransactorSession struct {
	Contract     *BridgesepoilaTransactor // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts        // Transaction auth options to use throughout this session
}

// BridgesepoilaRaw is an auto generated low-level Go binding around an Ethereum contract.
type BridgesepoilaRaw struct {
	Contract *Bridgesepoila // Generic contract binding to access the raw methods on
}

// BridgesepoilaCallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type BridgesepoilaCallerRaw struct {
	Contract *BridgesepoilaCaller // Generic read-only contract binding to access the raw methods on
}

// BridgesepoilaTransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type BridgesepoilaTransactorRaw struct {
	Contract *BridgesepoilaTransactor // Generic write-only contract binding to access the raw methods on
}

// NewBridgesepoila creates a new instance of Bridgesepoila, bound to a specific deployed contract.
func NewBridgesepoila(address common.Address, backend bind.ContractBackend) (*Bridgesepoila, error) {
	contract, err := bindBridgesepoila(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &Bridgesepoila{BridgesepoilaCaller: BridgesepoilaCaller{contract: contract}, BridgesepoilaTransactor: BridgesepoilaTransactor{contract: contract}, BridgesepoilaFilterer: BridgesepoilaFilterer{contract: contract}}, nil
}

// NewBridgesepoilaCaller creates a new read-only instance of Bridgesepoila, bound to a specific deployed contract.
func NewBridgesepoilaCaller(address common.Address, caller bind.ContractCaller) (*BridgesepoilaCaller, error) {
	contract, err := bindBridgesepoila(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &BridgesepoilaCaller{contract: contract}, nil
}

// NewBridgesepoilaTransactor creates a new write-only instance of Bridgesepoila, bound to a specific deployed contract.
func NewBridgesepoilaTransactor(address common.Address, transactor bind.ContractTransactor) (*BridgesepoilaTransactor, error) {
	contract, err := bindBridgesepoila(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &BridgesepoilaTransactor{contract: contract}, nil
}

// NewBridgesepoilaFilterer creates a new log filterer instance of Bridgesepoila, bound to a specific deployed contract.
func NewBridgesepoilaFilterer(address common.Address, filterer bind.ContractFilterer) (*BridgesepoilaFilterer, error) {
	contract, err := bindBridgesepoila(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &BridgesepoilaFilterer{contract: contract}, nil
}

// bindBridgesepoila binds a generic wrapper to an already deployed contract.
func bindBridgesepoila(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := BridgesepoilaMetaData.GetAbi()
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, *parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Bridgesepoila *BridgesepoilaRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Bridgesepoila.Contract.BridgesepoilaCaller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Bridgesepoila *BridgesepoilaRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Bridgesepoila.Contract.BridgesepoilaTransactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Bridgesepoila *BridgesepoilaRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Bridgesepoila.Contract.BridgesepoilaTransactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Bridgesepoila *BridgesepoilaCallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Bridgesepoila.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Bridgesepoila *BridgesepoilaTransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Bridgesepoila.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Bridgesepoila *BridgesepoilaTransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Bridgesepoila.Contract.contract.Transact(opts, method, params...)
}

// Send is a paid mutator transaction binding the contract method 0xff0d7c2f.
//
// Solidity: function send(uint32 channelId, uint64 timeoutHeight, uint64 timeoutTimestamp, bytes32 salt, (uint8,uint8,bytes) instruction) returns()
func (_Bridgesepoila *BridgesepoilaTransactor) Send(opts *bind.TransactOpts, channelId uint32, timeoutHeight uint64, timeoutTimestamp uint64, salt [32]byte, instruction Instruction) (*types.Transaction, error) {
	return _Bridgesepoila.contract.Transact(opts, "send", channelId, timeoutHeight, timeoutTimestamp, salt, instruction)
}

// Send is a paid mutator transaction binding the contract method 0xff0d7c2f.
//
// Solidity: function send(uint32 channelId, uint64 timeoutHeight, uint64 timeoutTimestamp, bytes32 salt, (uint8,uint8,bytes) instruction) returns()
func (_Bridgesepoila *BridgesepoilaSession) Send(channelId uint32, timeoutHeight uint64, timeoutTimestamp uint64, salt [32]byte, instruction Instruction) (*types.Transaction, error) {
	return _Bridgesepoila.Contract.Send(&_Bridgesepoila.TransactOpts, channelId, timeoutHeight, timeoutTimestamp, salt, instruction)
}

// Send is a paid mutator transaction binding the contract method 0xff0d7c2f.
//
// Solidity: function send(uint32 channelId, uint64 timeoutHeight, uint64 timeoutTimestamp, bytes32 salt, (uint8,uint8,bytes) instruction) returns()
func (_Bridgesepoila *BridgesepoilaTransactorSession) Send(channelId uint32, timeoutHeight uint64, timeoutTimestamp uint64, salt [32]byte, instruction Instruction) (*types.Transaction, error) {
	return _Bridgesepoila.Contract.Send(&_Bridgesepoila.TransactOpts, channelId, timeoutHeight, timeoutTimestamp, salt, instruction)
}
