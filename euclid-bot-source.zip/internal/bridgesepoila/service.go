package bridgesepoila

import (
	"context"
	"crypto/ecdsa"
	"fmt"
	"math/big"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
)

type Service struct {
	contract *Bridgesepoila
	client   bind.ContractBackend
	chainID  *big.Int
}

func NewService(client bind.ContractBackend, contractAddress common.Address, chainID *big.Int) (*Service, error) {
	contract, err := NewBridgesepoila(contractAddress, client)
	if err != nil {
		return nil, fmt.Errorf("failed to create UCS03 contract: %w", err)
	}

	return &Service{
		contract: contract,
		client:   client,
		chainID:  chainID,
	}, nil
}

func (s *Service) SendCrossChain(
	privateKey *ecdsa.PrivateKey,
	chainID *big.Int,
	channelId uint32,
	timeoutHeight uint64,
	timeoutTimestamp uint64,
	salt [32]byte,
	version uint8,
	opcode uint8,
	operand []byte,
) (*types.Transaction, error) {
	auth, err := bind.NewKeyedTransactorWithChainID(privateKey, chainID)
	if err != nil {
		return nil, fmt.Errorf("failed to create transactor: %w", err)
	}

	tx, err := s.contract.Send(auth, channelId, timeoutHeight, timeoutTimestamp, salt, struct {
		Version uint8
		Opcode  uint8
		Operand []byte
	}{
		Version: version,
		Opcode:  opcode,
		Operand: operand,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to send cross-chain: %w", err)
	}

	return tx, nil
}

func (s *Service) SendTransaction(
	privateKey *ecdsa.PrivateKey,
	chainID *big.Int,
	toAddress string,
	data string,
	value string,
) (*types.Transaction, error) {

	if s.client == nil {
		return nil, fmt.Errorf("client is nil")
	}
	if privateKey == nil {
		return nil, fmt.Errorf("private key is nil")
	}

	auth, err := bind.NewKeyedTransactorWithChainID(privateKey, chainID)
	if err != nil {
		return nil, fmt.Errorf("failed to create transactor: %w", err)
	}

	nonce, err := s.client.PendingNonceAt(context.Background(), auth.From)
	if err != nil {
		return nil, fmt.Errorf("failed to get nonce: %w", err)
	}

	gasPrice, err := s.client.SuggestGasPrice(context.Background())
	if err != nil {
		return nil, fmt.Errorf("failed to get gas price: %w", err)
	}

	to := common.HexToAddress(toAddress)
	dataBytes := common.FromHex(data)
	valueWei, ok := new(big.Int).SetString(value, 0)
	if !ok {
		return nil, fmt.Errorf("failed to parse value")
	}

	msg := ethereum.CallMsg{
		From:     auth.From,
		To:       &to,
		GasPrice: gasPrice,
		Value:    valueWei,
		Data:     dataBytes,
	}
	gasLimit, err := s.client.EstimateGas(context.Background(), msg)
	if err != nil {
		gasLimit = 200000
	}

	tx := types.NewTransaction(
		nonce,
		to,
		valueWei,
		gasLimit,
		gasPrice,
		dataBytes,
	)

	signedTx, err := auth.Signer(auth.From, tx)
	if err != nil {
		return nil, fmt.Errorf("failed to sign transaction: %w", err)
	}

	err = s.client.SendTransaction(context.Background(), signedTx)
	if err != nil {
		return nil, fmt.Errorf("failed to send transaction: %w", err)
	}

	return signedTx, nil
}
