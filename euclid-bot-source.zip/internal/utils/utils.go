package utils

import (
	"encoding/hex"
	"fmt"
	"math/big"
	"math/rand"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"time"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/fatih/color"
)

type NetworkConfig struct {
	BridgeContract string
	RouteSTT       []string
	RouteBera      []string
	RouteMon       []string
	RouteBnb       []string
	RPC            string
	Explorer       string
}

var Networks = map[string]NetworkConfig{
	"basesepolia": {
		RouteSTT: []string{
			"eth",
			"euclid",
			"stt",
		},
		RouteBera: []string{
			"eth",
			"sp500",
			"usdt",
			"euclid",
			"bera",
		},
		RouteMon: []string{
			"eth",
			"usdc",
			"usdt",
			"euclid",
			"mon",
		},
		RouteBnb: []string{
			"eth",
			"usdc",
			"usdt",
			"euclid",
			"bnb",
		},
		BridgeContract: "0xc3b9297130E49E0E514884cca150435a1324865b",
		RPC:            "https://sepolia.base.org",
		Explorer:       "https://sepolia.basescan.org",
	},
	"ethsepolia": {
		RPC:            "https://eth-sepolia.public.blastapi.io",
		Explorer:       "https://sepolia.etherscan.io",
		BridgeContract: "0x7f2CC9FE79961f628Da671Ac62d1f2896638edd5",
		RouteMon: []string{
			"eth",
			"euclid",
			"usdc",
			"mon",
		},
	},
}

func LogMessage(currentNum, total int, message, messageType string) {
	timestamp := time.Now().Format("2006-01-02 15:04:05")
	accountStatus := ""
	if currentNum > 0 && total > 0 {
		accountStatus = fmt.Sprintf("[%d/%d] ", currentNum, total)
	}

	var colorPrinter *color.Color
	var symbol string

	switch messageType {
	case "info":
		colorPrinter = color.New(color.FgCyan)
		symbol = "[i]"
	case "success":
		colorPrinter = color.New(color.FgGreen)
		symbol = "[✓]"
	case "error":
		colorPrinter = color.New(color.FgRed)
		symbol = "[-]"
	case "warning":
		colorPrinter = color.New(color.FgYellow)
		symbol = "[!]"
	case "process":
		colorPrinter = color.New(color.FgHiCyan)
		symbol = "[>]"
	default:
		colorPrinter = color.New(color.Reset)
		symbol = "[*]"
	}

	logText := fmt.Sprintf("%s %s", symbol, message)
	fmt.Printf("[%s] %s", timestamp, accountStatus)
	colorPrinter.Println(logText)
}

func ClearScreen() {
	var cmd *exec.Cmd
	if runtime.GOOS == "windows" {
		cmd = exec.Command("cmd", "/c", "cls")
	} else {
		cmd = exec.Command("clear")
	}
	cmd.Stdout = os.Stdout
	cmd.Run()
}

func StringToHex(input string) string {
	return hex.EncodeToString([]byte(input))
}

func WeiToEther(wei *big.Int) string {
	f := new(big.Float).SetInt(wei)
	f.Quo(f, big.NewFloat(1e18))
	return f.Text('f', 6)
}

func EtherToWei(amount string) *big.Int {
	f, _ := new(big.Float).SetString(amount)
	f.Mul(f, big.NewFloat(1e18))
	result := new(big.Int)
	f.Int(result)
	return result
}

func RandomAmount(max *big.Int) *big.Int {
	rand.Seed(time.Now().UnixNano())
	r := new(big.Int).Rand(rand.New(rand.NewSource(time.Now().UnixNano())), max)
	return r
}

func AmountToDecimals(amount string, decimals int) *big.Int {
	f, _ := new(big.Float).SetString(amount)
	multiplier := new(big.Float).SetFloat64(float64(1))
	multiplier.Quo(multiplier, big.NewFloat(1))
	for i := 0; i < decimals; i++ {
		multiplier.Mul(multiplier, big.NewFloat(10))
	}
	f.Mul(f, multiplier)
	result := new(big.Int)
	f.Int(result)
	return result
}

func Remove0xPrefix(privateKey string) string {
	if strings.HasPrefix(privateKey, "0x") {
		return privateKey[2:]
	}
	return privateKey
}

func RandomAmountInRange(minAmount, maxAmount *big.Int) *big.Int {
	if minAmount.Cmp(maxAmount) == 0 {
		return minAmount
	}

	diff := new(big.Int).Sub(maxAmount, minAmount)
	randValue := big.NewInt(0).Rand(rand.New(rand.NewSource(time.Now().UnixNano())), diff)
	return new(big.Int).Add(minAmount, randValue)
}

func GenerateSalt(sender common.Address) [32]byte {
	return crypto.Keccak256Hash([]byte(fmt.Sprintf("%s%d", sender.Hex(), time.Now().Unix())))
}
