package utils

import (
	"encoding/json"
	"fmt"
)

type SwapResponse struct {
	ChainID  string `json:"chain_id"`
	Contract string `json:"contract"`
	Msgs     []struct {
		To    string `json:"to"`
		Data  string `json:"data"`
		Value string `json:"value"`
	} `json:"msgs"`
	Sender struct {
		Address  string `json:"address"`
		ChainUID string `json:"chain_uid"`
	} `json:"sender"`
	Type string `json:"type"`
}

func ParseSwapResponse(data []byte) (*SwapResponse, error) {
	var response SwapResponse
	err := json.Unmarshal(data, &response)
	if err != nil {
		return nil, fmt.Errorf("error unmarshaling response: %v", err)
	}
	return &response, nil
}
