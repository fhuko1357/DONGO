package chain

import (
	"context"
	"encoding/json"
	"euclid-bot/internal/pkg/request"
	"fmt"
	"net/url"
	"strings"
)

type CheckUser struct {
	client *request.Client
}

func NewCheckUser() (*CheckUser, error) {
	client, err := request.New(&request.ClientOption{
		BaseURL: "https://testnet.api.euclidprotocol.com",
		Headers: map[string]string{
			"Content-Type": "application/json",
		},
	})
	if err != nil {
		return nil, err
	}

	return &CheckUser{
		client: client,
	}, nil
}

func (c *CheckUser) GetLeaderboard(walletAddress string, page int, limit int) ([]byte, error) {
	walletAddress = strings.ToLower(walletAddress)

	path := fmt.Sprintf("/api/v1/leaderboard?page=%d&limit=%d&wallet_address=%s",
		page, limit, url.QueryEscape(walletAddress))
	return c.client.Get(context.Background(), path)
}

type LeaderboardResponse struct {
	Limit      int    `json:"limit"`
	Page       int    `json:"page"`
	Results    []User `json:"results"`
	TotalUsers int    `json:"total_users"`
	UserStats  User   `json:"user_stats"`
}

type User struct {
	Name          string  `json:"name"`
	PassportID    string  `json:"passport_id"`
	Rank          int     `json:"rank"`
	TotalTxns     int     `json:"total_txns"`
	TotalVolume   float64 `json:"total_volume"`
	WalletAddress string  `json:"wallet_address"`
}

func (c *CheckUser) GetUserStats(walletAddress string) (*User, error) {

	data, err := c.GetLeaderboard(walletAddress, 1, 10)
	if err != nil {
		return nil, fmt.Errorf("failed to get leaderboard data: %w", err)
	}

	var response LeaderboardResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse leaderboard data: %w", err)
	}

	return &response.UserStats, nil
}
