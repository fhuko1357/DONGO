package chain

import (
	"context"
	"euclid-bot/internal/pkg/request"
	"strings"
)

type Tracker struct {
	client *request.Client
}

func NewTracker() (*Tracker, error) {
	client, err := request.New(&request.ClientOption{
		BaseURL: "https://testnet.euclidswap.io",
		Headers: map[string]string{
			"accept":       "application/json, text/plain, */*",
			"content-type": "application/json",
		},
	})
	if err != nil {
		return nil, err
	}
	return &Tracker{client: client}, nil
}

func (t *Tracker) TrackSwap(ctx context.Context, chainUID, txHash, walletAddress string, reffcode string) error {
	_, err := t.client.Post(ctx, "/api/intract-track", map[string]interface{}{
		"chain_uid":      chainUID,
		"tx_hash":        strings.ToLower(txHash),
		"wallet_address": strings.ToLower(walletAddress),
		"referral_code":  reffcode,
		"type":           "swap",
	})
	return err
}

// func (t *Tracker) TrackSwap(ctx context.Context, chainUID, txHash, walletAddress string) ([]byte, error) {
// 	lowerAddress := strings.ToLower(walletAddress)

// 	payload := map[string]interface{}{
// 		"chain_uid":      chainUID,
// 		"tx_hash":        strings.ToLower(txHash),
// 		"wallet_address": lowerAddress,
// 		"type": "swap",
// 	}

// 	response, err := t.client.Post(ctx, "/api/intract-track", payload)
// 	if err != nil {
// 		return nil, fmt.Errorf("API request failed: %w", err)
// 	}

// 	return response, nil
// }
