package chain

import (
	"context"
	"crypto/ecdsa"
	"euclid-bot/internal/bridgesepoila"
	"euclid-bot/internal/pkg/ethclient"
	"euclid-bot/internal/proxy"
	"euclid-bot/internal/utils"
	"fmt"
	"log"
	"time"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
)

type Config interface {
	GetRandomDelay() time.Duration
}

func (b *BaseApi) ExecuteSwap(ctx context.Context, amountIn, address, lessThanOrEqual, recipient, senderAddress string) (interface{}, error) {
	networkConfig := utils.Networks["basesepolia"]

	payload := createSwapPayload(amountIn, address, lessThanOrEqual, recipient, senderAddress, "base", "somnia", networkConfig.RouteSTT)

	response, err := b.client.Post(ctx, "/api/v1/execute/astro/swap", payload)
	if err != nil {
		log.Printf("Failed to execute swap: %v", err)
		return nil, fmt.Errorf("API request failed: %w", err)
	}

	swapResponse, err := utils.ParseSwapResponse(response)
	if err != nil {
		return nil, fmt.Errorf("failed to parse swap response: %w", err)
	}

	return swapResponse, nil
}

func (b *BaseApi) ExecuteSwapBera(ctx context.Context, amountIn, address, lessThanOrEqual, recipient, senderAddress string) (interface{}, error) {
	networkConfig := utils.Networks["basesepolia"]

	payload := createSwapPayload(amountIn, address, lessThanOrEqual, recipient, senderAddress, "base", "bepolia", networkConfig.RouteBera)

	response, err := b.client.Post(ctx, "/api/v1/execute/astro/swap", payload)
	if err != nil {
		log.Printf("Failed to execute swap: %v", err)
		return nil, fmt.Errorf("API request failed: %w", err)
	}

	swapResponse, err := utils.ParseSwapResponse(response)
	if err != nil {
		return nil, fmt.Errorf("failed to parse swap response: %w", err)
	}

	return swapResponse, nil
}

func (b *BaseApi) ExecuteSwapMon(ctx context.Context, amountIn, address, lessThanOrEqual, recipient, senderAddress string) (interface{}, error) {
	networkConfig := utils.Networks["basesepolia"]

	payload := createSwapPayload(amountIn, address, lessThanOrEqual, recipient, senderAddress, "base", "monad", networkConfig.RouteMon)

	response, err := b.client.Post(ctx, "/api/v1/execute/astro/swap", payload)
	if err != nil {
		log.Printf("Failed to execute swap: %v", err)
		return nil, fmt.Errorf("API request failed: %w", err)
	}

	swapResponse, err := utils.ParseSwapResponse(response)
	if err != nil {
		return nil, fmt.Errorf("failed to parse swap response: %w", err)
	}

	return swapResponse, nil
}

func (b *BaseApi) ExecuteSwapBnb(ctx context.Context, amountIn, address, lessThanOrEqual, recipient, senderAddress string) (interface{}, error) {
	networkConfig := utils.Networks["basesepolia"]

	payload := createSwapPayload(amountIn, address, lessThanOrEqual, recipient, senderAddress, "base", "bsc", networkConfig.RouteBnb)

	response, err := b.client.Post(ctx, "/api/v1/execute/astro/swap", payload)
	if err != nil {
		log.Printf("Failed to execute swap: %v", err)
		return nil, fmt.Errorf("API request failed: %w", err)
	}

	swapResponse, err := utils.ParseSwapResponse(response)
	if err != nil {
		return nil, fmt.Errorf("failed to parse swap response: %w", err)
	}

	return swapResponse, nil
}

func ProcessETHSwap(privateKey *ecdsa.PrivateKey, amountIn string, swapType string, cfg Config, reffcode string) {
	baseConfig := utils.Networks["basesepolia"]
	proxy.LoadProxies()
	proxy, err := proxy.GetRandomProxy(1, 1)
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to get proxy: %v", err), "error")
		return
	}

	client, err := ethclient.New(context.Background(), baseConfig.RPC, proxy)
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to create Ethereum client: %v", err), "error")
		return
	}
	defer client.Close()

	chainID, err := client.ChainID(context.Background())
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to get chain ID: %v", err), "error")
		return
	}

	senderAddress := crypto.PubkeyToAddress(privateKey.PublicKey).Hex()
	amountWei := utils.EtherToWei(amountIn)
	baseSvc, err := NewApiBase()
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to create BaseSepolia service: %v", err), "error")
		return
	}

	var swapData interface{}
	switch swapType {
	case "stt":
		swapData, err = baseSvc.ExecuteSwap(context.Background(), amountWei.String(), senderAddress, "0", senderAddress, senderAddress)
	case "bera":
		swapData, err = baseSvc.ExecuteSwapBera(context.Background(), amountWei.String(), senderAddress, "0", senderAddress, senderAddress)
	case "mon":
		swapData, err = baseSvc.ExecuteSwapMon(context.Background(), amountWei.String(), senderAddress, "0", senderAddress, senderAddress)
	case "bnb":
		swapData, err = baseSvc.ExecuteSwapBnb(context.Background(), amountWei.String(), senderAddress, "0", senderAddress, senderAddress)
	default:
		utils.LogMessage(0, 0, "Invalid swap type", "error")
		return
	}

	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to get swap data: %v", err), "error")
		return
	}

	swapResponse, ok := swapData.(*utils.SwapResponse)
	if !ok || len(swapResponse.Msgs) == 0 {
		utils.LogMessage(0, 0, "Invalid swap response", "error")
		return
	}

	bridgeSvc, err := bridgesepoila.NewService(client, common.HexToAddress(swapResponse.Contract), chainID)
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to create bridge service: %v", err), "error")
		return
	}

	utils.LogMessage(0, 0, "Sending swap transaction...", "process")
	signedTx, err := bridgeSvc.SendTransaction(
		privateKey,
		chainID,
		swapResponse.Msgs[0].To,
		swapResponse.Msgs[0].Data,
		swapResponse.Msgs[0].Value,
	)
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to send swap transaction: %v", err), "error")
		return
	}

	if signedTx == nil {
		utils.LogMessage(0, 0, "Signed transaction is nil", "error")
		return
	}

	utils.LogMessage(0, 0, "Swap transaction sent successfully!", "success")
	utils.LogMessage(0, 0, fmt.Sprintf("Amount: %s", amountIn), "success")
	utils.LogMessage(0, 0, fmt.Sprintf("Tx hash: %s", signedTx.Hash().Hex()), "success")
	utils.LogMessage(0, 0, fmt.Sprintf("Explorer: %s/tx/%s", baseConfig.Explorer, signedTx.Hash().Hex()), "success")

	tracker, err := NewTracker()
	if err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to create tracker: %v", err), "warning")
		return
	}

	if err := tracker.TrackSwap(
		context.Background(),
		"base",
		signedTx.Hash().Hex(),
		senderAddress,
		reffcode,
	); err != nil {
		utils.LogMessage(0, 0, fmt.Sprintf("Failed to track swap: %v", err), "warning")
	}
}
