package chain

import (
	"euclid-bot/internal/pkg/request"
	"fmt"
)

type BaseApi struct {
	client *request.Client
}

func NewApiBase() (*BaseApi, error) {
	client, err := request.New(&request.ClientOption{
		BaseURL: "https://testnet.api.euclidprotocol.com",
		Headers: map[string]string{
			"Content-Type": "application/json",
		},
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create HTTP client: %w", err)
	}

	return &BaseApi{
		client: client,
	}, nil
}

func createSwapPayload(amountIn, address, lessThanOrEqual, recipient, senderAddress string, senderFrom string, chainId string, route []string) map[string]interface{} {
	return map[string]interface{}{
		"amount_in": amountIn,
		"asset_in": map[string]interface{}{
			"token": "eth",
			"token_type": map[string]interface{}{
				"__typename": "NativeTokenType",
				"native": map[string]interface{}{
					"__typename": "NativeToken",
					"denom":      "eth",
				},
			},
		},
		"slippage": "500",
		"cross_chain_addresses": []map[string]interface{}{
			{
				"user": map[string]interface{}{
					"address":   address,
					"chain_uid": chainId,
				},
				"limit": map[string]interface{}{
					"less_than_or_equal": lessThanOrEqual,
				},
			},
		},
		"partnerFee": map[string]interface{}{
			"partner_fee_bps": 10,
			"recipient":       recipient,
		},
		"sender": map[string]interface{}{
			"address":   senderAddress,
			"chain_uid": senderFrom,
		},
		"swap_path": map[string]interface{}{
			"path": []map[string]interface{}{
				{
					"route":      route,
					"dex":        "euclid",
					"amount_in":  amountIn,
					"amount_out": "",
					"chain_uid":  "vsl",
					"amount_out_for_hops": []string{
						"usdc: 938523",
						"usdt: 16264387",
						"euclid: 155506",
						fmt.Sprintf("%s: %s", route[len(route)-1], lessThanOrEqual),
					},
				},
			},
			"total_price_impact": "0.00",
		},
	}
}
